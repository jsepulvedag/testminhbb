<?php
if (!defined('RAPIDLEECH')) {die("not load primary script");}

$no_cache = true; #true - Prohibition by Browser; otherwise allowed (You should leave this intact unless you know what you are doing)
$images_via_php = false; #true - RapidShare images are downloaded through the script, but it requires ssl support; turn it off if you can't see the image.
$redir = true; # true - Redirect passive method (You should leave this intact unless you know what you are doing)
$show_all = true; # true - To show all files in the catalog, false to hide it

$login = false; # false - Authorization mode is off, true - on
$users = array('admin' => 'admin', 'test' => 'test'); # false - Authorization mode is off, enter the username and password in the given way

//$rs["de"] = array('user' => 'your username', 'pass' => 'your password'); # Remove '//' from the beginning and enter your username and password for rapidshare.de premium account
//$rs["com"] = array('user' => 'your username', 'pass' => 'your password'); # Remove '//' from the beginning and enter your username and password for rapidshare.com premium account
?>