<?php
if (!defined('RAPIDLEECH')) {die("not load primary script");}

function GetCookies($content)
	{
	global $nn;
	list($header,$info) = explode($nn.$nn,$content);
	
	$i = preg_match_all("/Set-Cookie: (.*)\n/",$header,$matches);
	for ($j=0; $j<$i; $j++)
		{
		$res[]=$matches[1][$j];
		}
	return $res;
	}

function logged_user($u)
	{
	global $_SERVER;
	foreach ($u as $user => $pass)
		{
		if ($_SERVER['PHP_AUTH_USER'] == $user && $_SERVER['PHP_AUTH_PW'] == $pass)
			{
			return $user;
			}
		}
	return false;
	}

function is_present($lpage, $mystr, $strerror = "", $head = 1)
	{
		$strerror = $strerror ? $strerror : $mystr;
		if (stristr($lpage, $mystr))
			{
				html_error($strerror, $head);
			}
	}

function is_notpresent($lpage, $mystr, $strerror, $head = 1)
	{
		if (!stristr($lpage,$mystr))
			{
				html_error($strerror, $head);
			}
	}

function insert_location($newlocation)
	{
	global $nn;
	list($location, $list) = explode("?", $newlocation);
	$list = explode("&", $list);
	print "<form action=\"$location\" method=\"post\">".$nn;
	foreach ($list as $l)
		{
		list($name, $value) = explode("=", $l);
		print "<input type=\"hidden\" name=\"$name\" value=\"$value\">".$nn;
		}
	?>
<script language="JavaScript">
void(document.forms[0].submit());
</script>
</form>
</body>
</html>
	<?php
	flush();
	}

function insert_timer($countd, $caption ="", $timeouttext = "", $hide = false)
	{
		if (!$countd || !is_numeric($countd)) {return false;}
	
		$timerid = rand(1000, time());
?>
<center><span id="global<?php echo $timerid;?>"><span style="FONT-FAMILY: Tahoma; FONT-SIZE: 10px;"><?php echo "<big>$caption</big>"; ?></span>&nbsp;<span id="timerlabel<?php echo $timerid; ?>" style="FONT-FAMILY: Tahoma; FONT-SIZE: 10px;"></span></span></center>
<script language="javascript">
var count<?php echo $timerid; ?>=<?php echo $countd; ?>;
function timer<?php echo $timerid; ?>()
	{
		if(count<?php echo $timerid; ?> > 0)
			{
				document.getElementById('timerlabel<?php echo $timerid; ?>').innerHTML = "<big>Please wait <b>" + count<?php echo $timerid.".toFixed(1)"; ?> + "</b> seconds...</big>";
				count<?php echo $timerid; ?> = count<?php echo $timerid; ?> - .5;
				setTimeout("timer<?php echo $timerid; ?>()", 500)
			}
	}
timer<?php echo $timerid; ?>();
</script>
<?php
		flush();
		sleep($countd);
		
		if ($hide === true)
			{
?>			
<script language="javascript">
document.getElementById('global<?php echo $timerid; ?>').style.display = 'none';
</script>
<?php
				flush();
				return true;
			}		

		if ($timeouttext)
			{
?>			
<script language="javascript">
document.getElementById('global<?php echo $timerid; ?>').innerHTML = '<?php echo $timeouttext; ?>';
</script>
<?php
				flush();
				return true;
			}
	}

function insert_new_timer($countd, $displaytext, $caption = "")
	{
	if (!is_numeric($countd)) {html_error("Wrong Counter");}
	?>
<p><div id="code"></div></p>
<p><center><div id="dl" style="FONT-FAMILY: Tahoma; FONT-SIZE: 10px;"><h4>ERROR: Please enable JavaScript.</h4></div></center></p>
<script language="JavaScript">
var c = <?php echo $countd; ?>;
fc();
function fc() {
	if(c>0) {
		document.getElementById("dl").innerHTML = "<big><?php echo $caption; ?> Please wait <b>" + c.toFixed(1) + "</b> seconds...</big>";
		c = c - .5;
		setTimeout("fc()", 500);
		}
	else {
		document.getElementById("dl").style.display="none";
		document.getElementById("code").innerHTML = unescape("<?php echo $displaytext; ?>");
		}
	}
</script>
</body>
</html>
	<?php
	flush();
	exit;
	}

function is_page($lpage)
  {
  	global $lastError;
  	if (!$lpage)
  		{
  			html_error("Error retriving the link<br>$lastError");
  		}
  }

function getftpurl($host, $port, $url, $saveToFile = 0) {
global $nn, $lastError, $PHP_SELF, $AUTH, $IS_FTP, $FtpBytesTotal, $FtpBytesReceived, $FtpTimeStart, $FtpChunkSize;

$ftp = new ftp(FALSE, FALSE);
  if(!$ftp->SetServer($host, (int)$port))
    {
        $ftp->quit();
        $lastError = "Couldn't establish connection with the server ".$host.":".$port.".<br>".
                     "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
        return FALSE;
    }
  else
    {
        if(!$ftp->connect())
          {
              $ftp->quit();
              $lastError = "Couldn't connect to the server ".$host.":".$port.".<br>".
                           "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
              return FALSE;
          }
        else
          {
                if (!$ftp->login($AUTH["ftp"]["login"], $AUTH["ftp"]["password"]))
                  {
                      $ftp->quit();
                      $lastError = "Incorrect username and/or password <b>".$AUTH["ftp"]["login"].":".$AUTH["ftp"]["password"]."</b>.<br>".
                                   "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
                      return FALSE;
                  }
                else
                  {
					  echo "<p>Connected to: <b>".$host."</b>...<br>";
                      //$ftp->Passive(FALSE);
                      $tmp = explode("/", $url);
                      $ftp_file = array_pop($tmp);
                      $ftp_dir = implode("/", $tmp);
                      $ftp->chdir($ftp_dir);
                      $fileSize = $FtpBytesTotal = $ftp->filesize($ftp_file);
                      $FtpChunkSize = round($fileSize / 333);
                      
                      list($saveToFile,$tmp) = explode('?',$saveToFile);
                      
                      if(file_exists($saveToFile))
                        {
                            $saveToFile = dirname($saveToFile).PATH_SPLITTER.time()."_".basename($saveToFile);
                        }
                      echo "File <b>".$saveToFile."</b>, Size <b>".bytesToKbOrMbOrGb($fileSize)."</b>...<br>";
                      ?>
<br>
<table cellspacing="0" cellpadding="0" style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;">
<tr>
<td></td>
<td>
<div style='border:#BBBBBB 1px solid; width:300px; height:10px;'>
<div id="progress" style='background-color:#000099; margin:1px; width:0%; height:8px;'>
</div>
</div>
</td>
<td></td>
<tr>
<tr>
<td align="left" id="received">0 KB</td>
<td align="center" id="percent">0%</td>
<td align="right" id="speed">0 KB/s</td>
</tr>
</table>
<br>
<div id="resume" align="center" style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;"></div>
<script language="javascript">
function pr(percent, received, speed){
	document.getElementById("received").innerHTML = '<b>' + received + '</b>';
	document.getElementById("percent").innerHTML = '<b>' + percent + '%</b>';
	document.getElementById("progress").style.width = percent + '%';
	document.getElementById("speed").innerHTML = '<b>' + speed + ' KB/s</b>';
	document.title = 'Downloaded ' + percent + '%';
	return true;
	}

	function mail(str, field) {
	document.getElementById("mailPart." + field).innerHTML = str;
	return true;
	}
</script>
<br>
<?php
                      $FtpTimeStart = getmicrotime();
                      if($ftp->get($ftp_file, $saveToFile))
                        {
                            return array("time"              => sec2time(round($time)),
                                         "speed"             => round($FtpBytesTotal / 1024 / (getmicrotime() - $FtpTimeStart), 2),
                                         "received"          => TRUE,
                                         "size"              => bytesToKbOrMbOrGb($fileSize),
                                         "bytesReceived"     => $FtpBytesReceived,
                                         "bytesTotal"        => $FtpBytesTotal,
                                         "file"              => $saveToFile);
                        }
                      else
                        {
                            return FALSE;
                        }
                      $ftp->quit();
                  }
          }
    }
}

function geturl($host, $port, $url, $referer = 0, $cookie = 0, $post = 0, $saveToFile = 0, $proxy = 0, $pauth = 0,$auth = 0, $scheme = "http", $resume_from = 0) {
global $nn, $lastError, $PHP_SELF, $AUTH, $IS_FTP, $FtpBytesTotal, $FtpBytesReceived, $FtpTimeStart, $FtpChunkSize, $Resume, $bytesReceived, $fs;

$scheme.= "://";

if (($post !== 0) && ($scheme == "http://"))
  {
    $method = "POST";
    $postdata = formpostdata($post);

    $length = strlen($postdata);
    $content_tl = "Content-Type: application/x-www-form-urlencoded".$nn."Content-Length: ".$length.$nn;
  }
else
  {
    $method = "GET";
    $postdata = "";
    $content_tl = "";
  }

if ($cookie)
	{
		if (is_array($cookie))
			{
				for( $i = 0; $i < count($cookie); $i++)
					{
						$cookies .= "Cookie: ".$cookie[$i].$nn;
					}
			}
		else
			{
				$cookies = "Cookie: ".$cookie.$nn;
			}
	}
$referer = $referer ? "Referer: ".$referer.$nn : "";

if ($scheme == "https://")
	{
	$scheme = "ssl://";
	$port = 443;
	}

if($proxy)
	{
    list($proxyHost, $proxyPort) = explode(":", $proxy);
    $url = $scheme.$host.":".$port.$url;
    $host = $host.":".$port;
	}

if ($scheme != "ssl://")
	{
	$scheme = "";
	}

if ($saveToFile)
	{
	if ($resume_from !== 0 && is_numeric($resume_from))
		{
		$Resume["use"] = TRUE;
		$Resume["from"] = $resume_from;
		}

	if ($Resume["use"] !== TRUE)
		{
		$Resume["use"] = FALSE;
		$Resume["from"] = 0;
		}
	}

$Resume["enable"] = TRUE;

$http_auth = (!empty($auth)) ? "Authorization: Basic ".$auth.$nn : "";
$proxyauth = ($pauth) ? "Proxy-Authorization: Basic ".$pauth.$nn : "";

$zapros=
$method." ".str_replace(" ", "%20", $url)." HTTP/1.0".$nn.
"Host: ".$host.$nn.
"User-Agent: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Alexa Toolbar)".$nn.
"Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5".$nn.
"Accept-Language: en-en,en;q=0.5".$nn.
"Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7".$nn.
"Pragma: no-cache".$nn.
"Cache-Control: no-chache".$nn.
($Resume["use"] === TRUE ? "Range: bytes=".$Resume["from"]."-".$nn : "").
$http_auth.
$proxyauth.
$referer.
$cookies.
"Keep-Alive: 300".$nn.
"Connection: Close".$nn.
$content_tl.$nn.$postdata;
//write_file("debug", $zapros);

$fp = @fsockopen($proxyHost ? $scheme.$proxyHost : $scheme.$host, $proxyPort ? $proxyPort : $port, &$errno, &$errstr, 15);

if (!$fp)
	{
	html_error("Error open socket [".($proxyHost ? $proxyHost : $host).':'.($proxyPort ? $proxyPort : $port)."]");
	}

socket_set_timeout($fp, 300);

if($errno || $errstr)
  {
  //echo $errno;
  $lastError = $errstr;
  
  return false;
  }

if ($saveToFile)
	{
	if ($proxy)
		{
		echo "<p>Connected to proxy: <b>".$proxy."</b>...<br>\n";
		echo "GET: <b>".$host.$url."</b>...<br>\n";
		}
	else
		{
		echo "<p>Connected to: <b>".$host."</b>...<br>";
		}
	}

fputs($fp,$zapros);
fflush($fp);
$timeStart = getmicrotime();

while(!feof($fp))
	{
 	$data = @fgets($fp, 128);
 	if ($data === false)
		{
		break;
		}

    //fwrite($f, $data);
    if($saveToFile)
      {
        if($headersReceived)
          {
            $bytesSaved = fwrite($fs, $data);
            if($bytesSaved > -1)
              {
                $bytesReceived += $bytesSaved;
              }
            else
              {
                echo "It is not possible to carry out a record in File ".$saveToFile;
                return false;
              }
              if($bytesReceived >= $bytesTotal)
                {
                  $percent = 100;
                }
              else
                {
                  $percent = round(($bytesReceived + $Resume["from"]) / ($bytesTotal + $Resume["from"]) * 100, 2);
                }
              if($bytesReceived > $last + $chunkSize)
              {
                $received = bytesToKbOrMbOrGb($bytesReceived + $Resume["from"]);
                $time = getmicrotime() - $timeStart;
                $chunkTime = $time - $lastChunkTime;
                $chunkTime = $chunkTime ? $chunkTime : 1;
                $lastChunkTime = $time;
                $speed = round($chunkSize / 1024 / $chunkTime, 2);
                //echo "������� <b>".$received."</b> &mdash; <b>".$percent."%</b>; time &mdash; <b>".$tmpTime."</b>; speed &mdash; <b>".$speed." KB/s</b><br>";
                echo "<script>pr('".$percent."', '".$received."', '".$speed."')</script>\r\n";
                $last = $bytesReceived;
              }
          }
        else
          {
            $tmp .= $data;
            if(stristr($tmp, "\n\n"))
              {
                  $det = "\n\n";
              }
            elseif(stristr($tmp, $nn.$nn))
              {
                  $det = $nn.$nn;
              }
            if($det)
              {
                $tmp = explode($det, $tmp);
                $redirect = trim(cut_str($tmp[0], "Location:", "\n"));
                if($redirect)
					{
                    $lastError = "Error! it is redirected to [".$redirect."] On the course of events, the reference became obsolete. So start from the beginning...<br><br><a href=\"".$PHP_SELF."\" style=\"color: #0000FF;\">Main</a>";
                    return FALSE;
					}
                if(in_array(cut_str($tmp[0], "WWW-Authenticate: ", " "), array("Basic", "Digest")))
					{
                    $lastError = "This site requires authorization. For the indication of username and password of access it is necessary to use similar url:<br>http://<b>login:password@</b>www.site.com/file.exe";
                    return FALSE;
					}
				/*
				if (stristr($tmp[0], "Accept-Ranges:"))
					{
					$Resume["enable"] = TRUE;
					}
				else
					{
					$Resume["enable"] = FALSE;
					}
				*/
				if ($Resume["use"] === TRUE && !stristr($tmp[0], "Content-Range:"))
					{
					if (stristr($tmp[0], "503 Limit Exceeded"))
						{
						$lastError = "Resume limit exceeded";
						}
					else
						{
						$lastError = "This server doesn't support resume";
						}
					return FALSE;
					}
				$ContentDisposition = trim(cut_str($tmp[0], "Content-Disposition:", "\n"))."\n";
				if ($ContentDisposition && stristr($ContentDisposition, "filename="))
					{
					$FileName = trim(trim(trim(cut_str($ContentDisposition, "filename=", "\n")), ";"), '"');
					$saveToFile = dirname($saveToFile).PATH_SPLITTER.$FileName;
					}
				$ContentType = trim(cut_str($tmp[0], "Content-Type:", "\n"));
				if (stristr($host, "rapidshare") && stristr($ContentType, "text/html") && stristr($tmp[0], "404 Not Found"))
					{
					$page = $tmp[1];
					unset($saveToFile);
					$NoDownload = TRUE;
					}
				elseif (stristr($host, "megaupload") && stristr($ContentType, "text/html"))
					{
					$page = $tmp[1];
					unset($saveToFile);
					$NoDownload = TRUE;
					}
				if (!$NoDownload)
					{
                if (!$fs)
					{
					list($saveToFile, $temp) = explode('?',$saveToFile);
					
					if(file_exists($saveToFile) && $Resume["use"] === TRUE)
						{
						$fs = @fopen($saveToFile, "ab");
						if(!$fs)
							{
							$lastError = "It is not possible to open the file ".$saveToFile." for writing<br>".
										 "Wrong Installation, that the way for the retention is assigned correctly and in the script".
										 "File couldn't be stored into this folder (try chmod the folder to 777).<br>".
										 "<a href=\"javascript:location.reload();\" style=\"color: #0000FF;\">Try again</a>";
							return FALSE;
							}
						}
					else
						{
						if (file_exists($saveToFile))
							{
							$saveToFile = dirname($saveToFile).PATH_SPLITTER.time()."_".basename($saveToFile);
							}
						$fs = @fopen($saveToFile, "wb");
						if(!$fs)
							{
							$secondName = dirname($saveToFile).PATH_SPLITTER.str_replace(":", "", str_replace("?", "", basename($saveToFile)));
							$fs = @fopen($secondName, "wb");
							if(!$fs)
								{
								$lastError = "It is not possible to open the file ".$saveToFile." for writing<br>".
							 				 "Wrong Installation, that the way for the retention is assigned correctly and in the script".
							 				 "File couldn't be stored into this folder (try chmod the folder to 777).<br>".
							 				 "<a href=\"javascript:location.reload();\" style=\"color: #0000FF;\">Try again</a>";
								return FALSE;
								}
							}
						}
					flock($fs, LOCK_EX);
					}
                $bytesSaved = fwrite($fs, $tmp[1]);
                if($bytesSaved > -1)
                  {
                    $bytesReceived += $bytesSaved;
                  }
                else
                  {
                    echo "It is not possible to carry out a record in File".$saveToFile."<br>";
                    return FALSE;
                  }
                $headersReceived = true;
                $bytesTotal = trim(cut_str($tmp[0], "Content-Length:", "\n"));
                if ($Resume["use"] === TRUE && stristr($tmp[0], "Content-Range:"))
					{
					list($temp, $Resume["range"]) = explode(" ", trim(cut_str($tmp[0], "Content-Range:", "\n")));
					list($Resume["range"], $fileSize) = explode("/", $Resume["range"]);
					$fileSize = bytesToKbOrMbOrGb($fileSize);
					}
				else
					{
					$fileSize = bytesToKbOrMbOrGb($bytesTotal);
					}
                $chunkSize = round($bytesTotal / 333);
				echo "File <b>".$saveToFile."</b>, Size <b>".$fileSize."</b>...<br>";
				?>
<br>
<table cellspacing="0" cellpadding="0" style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;">
<tr>
<td></td>
<td>
<div style='border:#BBBBBB 1px solid; width:300px; height:10px;'>
<div id="progress" style='background-color:#000099; margin:1px; width:0%; height:8px;'>
</div>
</div>
</td>
<td></td>
<tr>
<tr>
<td align="left" id="received">0 KB</td>
<td align="center" id="percent">0%</td>
<td align="right" id="speed">0 KB/s</td>
</tr>
</table>
<br>
<div id="resume" align="center" style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;"></div>
<script language="javascript">
function pr(percent, received, speed){
	document.getElementById("received").innerHTML = '<b>' + received + '</b>';
	document.getElementById("percent").innerHTML = '<b>' + percent + '%</b>';
	document.getElementById("progress").style.width = percent + '%';
	document.getElementById("speed").innerHTML = '<b>' + speed + ' KB/s</b>';
	document.title = 'Downloaded ' + percent + '%';
	return true;
	}

function mail(str, field) {
	document.getElementById("mailPart." + field).innerHTML = str;
	return true;
	}
</script>
<br>
<?php
                if ($Resume["use"] === TRUE)
					{
					$received = bytesToKbOrMbOrGb(filesize($saveToFile));
					$percent = round($Resume["from"] / ($bytesTotal + $Resume["from"]) * 100, 2);
					echo "<script>pr('".$percent."', '".$received."', '0')</script>\r\n";
					}
				}
              }
          }
      }
    else
      {
        $page .= $data;
      }
  }
//fclose($f);
if($saveToFile)
  {
    flock($fs, LOCK_UN);
    fclose($fs);
    if($bytesReceived <= 0)
      {
        $lastError = "Wrong Link? Error Downloading File...<br><a href=\"$PHP_SELF\">Go Back to Main</a>";
        fclose($fp);
        return FALSE;
      }
  }
fclose($fp);
if($saveToFile)
  {
    return array("time"              => sec2time(round($time)),
                 "speed"             => round($bytesTotal / 1024 / (getmicrotime() - $timeStart), 2),
                 "received"          => true,
                 "size"              => $fileSize,
                 "bytesReceived"     => ($bytesReceived + $Resume["from"]),
                 "bytesTotal"        => ($bytesTotal + $Resume["from"]),
                 "file"              => $saveToFile);
  }
else
  {
  if ($NoDownload)
	{
	if (stristr($host, "rapidshare"))
		{
		is_present($page, "is already downloading a file", "Your IP-address is already downloading a file", 0);
		is_present($page, "Download-session invalid", "Download-session invalid", 0);
		is_present($page, "Access-code wrong", "Access-code wrong", 0);
		is_present($page, "Too many wrong codes given", "Too many wrong codes given", 0);
		print $page;
		}
	elseif (stristr($host, "megaupload"))
		{
		is_present($page, "Download limit exceeded", "Download limit exceeded", 0);
		print $page;
		}
	}
  else
	{
  return $page;
	}
  }
}

function pause_download()
	{
	global $pathWithName, $Resume, $PHP_SELF, $_GET, $nn, $bytesReceived, $fs;
	$status = connection_status();
	if (($status == 2 || $status == 3) && $Resume["enable"] === TRUE && $bytesReceived > 0)
		{
		flock($fs, LOCK_UN);
		fclose($fs);
		clearstatcache();
		print "<form action=\"$PHP_SELF\" method=\"post\">".$nn;
		foreach ($_GET as $name => $value)
			{
			print "<input type=\"hidden\" name=\"$name\" value=\"$value\">".$nn;
			}
		print "<input type=\"hidden\" name=\"resume\" value=\"".filesize($pathWithName)."\">".$nn;
		print "<p align=\"center\" style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 11px;\"><a href=\"javascript:void(document.forms[0].submit());\">Click here to resume download</a></p>\r\n</form>\r\n";
		print "</center>\r\n</body>\r\n</html>";
		}
	elseif (($status == 2 || $status == 3) && $pathWithName && $bytesReceived > 0)
		{
		flock($fs, LOCK_UN);
		fclose($fs);
		print "<script language=\"javascript\">\r\ndocument.getElementById(\"resume\").innerHTML = \"<b>Couldn't finish download due to the script has exceeded the maximum execution time!</b>\";\r\n</script>\r\n";
		print "</center>\r\n</body>\r\n</html>";
		unlink($pathWithName);
		}
	exit;
	}

function formpostdata($post) {
global $first,$postdata;
$first = "";
$postdata = "";
array_walk($post, "fpd_f");
return $postdata;
}

function fpd_f($value, $key) {
global $postdata, $first;
$postdata .= $first.$key."=".urlencode($value);
$first = "&";
}

function cut_str($str, $left, $right){
$str = substr(stristr($str, $left), strlen($left));
$leftLen = strlen(stristr($str, $right));
$leftLen = $leftLen ? -($leftLen) : strlen($str);
$str = substr($str, 0, $leftLen);
return $str;
}

function write_file($file_name, $data, $trunk = 1) {
if($trunk == 1) {$mode = "wb";} elseif ($trunk == 0) {$mode = "ab";}
$fp = fopen($file_name, $mode);
if(!$fp)
  {
    return FALSE;
  }
else
  {
    if(!flock($fp, LOCK_EX))
      {
        return FALSE;
      }
    else
      {
        if(!fwrite($fp, $data))
          {
            return FALSE;
          }
        else
          {
            if(!flock($fp, LOCK_UN))
              {
                return FALSE;
              }
            else
              {
                if(!fclose($fp))
                  {
                    return FALSE;
                  }
              }
          }
      }
  }
return TRUE;
}

function read_file($file_name, $count = -1) {
if($count == -1) {$count = filesize($file_name);}
$fp = fopen($file_name, "rb");
flock($fp, LOCK_SH);
$ret = fread($fp, $count);
flock($fp, LOCK_UN);
fclose($fp);
return $ret;
}

function pre($var) {
echo "<pre>";
print_r($var);
echo "</pre>";
}

function getmicrotime(){
list($usec, $sec) = explode(" ",microtime());
return ((float)$usec + (float)$sec);
}

function html_error($msg, $head = 1){
global $PHP_SELF;
if ($head == 1)
	{
	?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title>Error...</title>
</head>
<body style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;">
	<?php
	}
	?>
<center>
<?php echo "<big><font color=\"red\">$msg</font></big>"; ?><br>
<a href="<?php echo $PHP_SELF; ?>">Go Back to Main</a>
</center>
</body>
</html>
<?php
exit;
}

function sec2time($time){
$hour = round($time / 3600, 2);
if($hour >= 1)
  {
    $hour = floor($hour);
    $time -= $hour * 3600;
  }
$min = round($time / 60, 2);
if($min >= 1)
  {
    $min = floor($min);
    $time -= $min * 60;
  }
$sec = $time;
$hour = ($hour >= 1) ? $hour." hour" : "";
$min = ($min >= 1) ? $min." min" : "";
$sec = ($sec >= 1) ? $sec." sec" : "";
return $hour.$min.$sec;
}
/*
function GetChunkSize($fsize)
	{
	if ($fsize <= 1024*1024) { return 4096; }
	if ($fsize <= 1024*1024*10) { return 4096*10; }
	if ($fsize <= 1024*1024*40) { return 4096*30; }
	if ($fsize <= 1024*1024*80) { return 4096*47; }
	if ($fsize <= 1024*1024*120) { return 4096*65; }
	if ($fsize <= 1024*1024*150) { return 4096*70; }
	if ($fsize <= 1024*1024*200) { return 4096*85; }
	if ($fsize <= 1024*1024*250) { return 4096*100; }
	if ($fsize <= 1024*1024*300) { return 4096*115; }
	if ($fsize <= 1024*1024*400) { return 4096*135; }
	if ($fsize <= 1024*1024*500) { return 4096*170; }
	if ($fsize <= 1024*1024*1000) { return 4096*200; }
	return 4096*210;
	}
*/
function bytesToKbOrMbOrGb($bytes){
if ($bytes >= (1024 * 1024 * 1024))
	$size = round($bytes / (1024 * 1024 * 1024), 2)." GB";
elseif ($bytes >= (1024 * 1024))
	$size = round($bytes / (1024 * 1024), 2)." MB";
elseif ($bytes >= (1024))
	$size = round($bytes / 1024, 2)." KB";
else
	$size = $bytes." B";
return $size;
}

function checkmail($mail) {
   if(strlen($mail) == 0)
     {
      return false;
     }
   if(!preg_match("/^[a-z0-9_\.-]{1,20}@(([a-z0-9-]+\.)+(com|net|org|mil|".
   "edu|gov|arpa|info|biz|inc|name|[a-z]{2})|[0-9]{1,3}\.[0-9]{1,3}\.[0-".
   "9]{1,3}\.[0-9]{1,3})$/is", $mail))
     {
       return false;
     }
   return true;
}

function xmail($from, $to, $subj, $text, $filename, $partSize = FALSE, $method = FALSE) {
  global $un;
  $fileContents = read_file($filename);
  $fileSize = strlen($fileContents);
  
	if ($partSize != FALSE & $method == "tc")
  		{
			$crc = strtoupper(dechex(crc32($fileContents)));
			$crc = str_repeat("0", 8 - strlen($crc)).$crc;
  		}
  			else
  		{
			$file = base64_encode($fileContents);
			$file = chunk_split($file);
			unset($fileContents);
		}
			

	if(!$file && !$fileContents) { return FALSE; }

	echo "Sending file <b>".basename($filename)."</b>...<br>";
	flush();
	sleep(1);
	for($i = 0; $i < strlen($subj); $i++)
		{
			$subzh .= "=".strtoupper(dechex(ord(substr($subj, $i, 1))));
		}

	$subj = "=?Windows-1251?Q?".$subzh.'?=';
	$un = strtoupper(uniqid(time()));
	$head = "From: ".$from."\n".
			"X-Mailer: PHP RapidLeech\n".
			"Reply-To: ".$from."\n".
			"Mime-Version: 1.0\n".
			"Content-Type: multipart/mixed; boundary=\"----------".$un."\"\n\n";
	$zag = "------------".$un."\nContent-Type: text/plain; charset=Windows-1251\n".
			"Content-Transfer-Encoding: 8bit\n\n".$text."\n\n".
			"------------".$un."\n".
			"Content-Type: application/octet-stream; name=\"".basename($filename)."\"\n".
			"Content-Transfer-Encoding: base64\n".
			"Content-Disposition: attachment; filename=\"".basename($filename)."\"\n\n";
	echo "<span id=mailPart.".md5(basename($filename))."></span><br>";
	flush();
	if($partSize)
		{
			$partSize = round($partSize);
			if($method == "rfc")
				{
					$multiHeadMain = 	"From: ".$from."\n".
										"X-Mailer: PHP RapidLeech\n".
										"Reply-To: ".$from."\n".
										"Mime-Version: 1.0\n".
										"Content-Type: message/partial; ";
					$totalParts = ceil(strlen($file) / $partSize);
					
					if ($totalParts == 1)
						{
							echo "No need spliting, Send single mail...<br>";
							flush();
							return mail($to, $subj, $zag.$file, $head) ? TRUE : FALSE;
						}
					
					echo "Spliting into Parts ".bytesToKbOrMbOrGb($partSize).", Method - RFC 2046...<br>";
					echo "Total Parts: <b>".$totalParts."</b><br>";
					$mailed = TRUE;
					for($i = 0; $i < $totalParts; $i++)
						{
							$multiHead = $multiHeadMain."id=\"".$filename."\"; number=".($i + 1)."; total=".$totalParts."\n\n";
							if($i == 0)
								{
									$multiHead = $multiHead.$head;
									$fileChunk = $zag.substr($file, 0, $partSize);
								}
									elseif($i == $totalParts - 1)
										{
											$fileChunk = substr($file, $i * $partSize);
										}
											else
										{
											$fileChunk = substr($file, $i * $partSize, $partSize);
										}
							echo "<script>mail('Sending parts� <b>".($i + 1)."</b>...', '".md5(basename($filename))."');</script>\r\n";
							flush();
							$mailed = $mailed & mail($to, $subj, $fileChunk, $multiHead);
							if (!$mailed) {return false;}
						}
				}
					elseif($method == "tc")
				{
					$totalParts = ceil($fileSize / $partSize);
					
					if ($totalParts == 1)
						{
							echo "No need spliting, Send single mail...<br>";
							flush();
							return mail($to, $subj, $zag.chunk_split(base64_encode($fileContents)), $head) ? TRUE : FALSE;
						}
									
					echo "Spliting into parts".bytesToKbOrMbOrGb($partSize).", Method - Total Commander...<br>";
					echo "Total Parts: <b>".$totalParts."</b><br>";
					$mailed = TRUE;
					$fileTmp = $filename;
					while(strpos($fileTmp, "."))
						{
							$fileName .= substr($fileTmp, 0, strpos($fileTmp, ".") + 1);
							$fileTmp = substr($fileTmp, strpos($fileTmp, ".") + 1);
						}
					$fileName = substr($fileName, 0, -1);
					for($i = 0; $i < $totalParts; $i++)
						{
							if($i == 0)
								{
									$fileChunk = substr($fileContents, 0, $partSize);
									$addHeads = addAdditionalHeaders(array("msg" => $text."\r\n"."File ".basename($filename)." (����� ".($i + 1)." �� ".$totalParts .").", "file" => array("filename" => $fileName.".crc", "stream" => chunk_split(base64_encode("filename=".basename($filename)."\r\n"."size=".$fileSize."\r\n"."crc32=".$crc."\r\n")))));
									$addHeads .= addAdditionalHeaders(array("file" => array("filename" => $fileName.".001", "stream" => chunk_split(base64_encode($fileChunk)))));
									//write_file($fileName.".crc", "filename=".basename($filename)."\r\n"."size=".$fileSize."\r\n"."crc32=".$crc."\r\n");
									//write_file($fileName.".001", $fileChunk);
								}
									elseif($i == $totalParts - 1)
										{
											$fileChunk = substr($fileContents, $i * $partSize);
											$addHeads =  addAdditionalHeaders(array("msg" => "File ".basename($filename)." (parts ".($i + 1)." from ".$totalParts .").",
											"file" => array("filename" => $fileName.".".(strlen($i + 1) == 2 ? "0".($i + 1) : (strlen($i + 1) == 1 ? "00".($i + 1) : ($i + 1))),
											"stream" => chunk_split(base64_encode($fileChunk)))));
											//write_file($fileName.".".(strlen($i + 1) == 2 ? "0".($i + 1) : (strlen($i + 1) == 1 ? "00".($i + 1) : ($i + 1))), $fileChunk);
										}
											else
										{
											$fileChunk = substr($fileContents, $i * $partSize, $partSize);
											$addHeads =  addAdditionalHeaders(array("msg" => "File ".basename($filename)." (parts ".($i + 1)." from ".$totalParts .").",
											"file" => array("filename" => $fileName.".".(strlen($i + 1) == 2 ? "0".($i + 1) : (strlen($i + 1) == 1 ? "00".($i + 1) : ($i + 1))),
											"stream" => chunk_split(base64_encode($fileChunk)))));
											//write_file($fileName.".".(strlen($i + 1) == 2 ? "0".($i + 1) : (strlen($i + 1) == 1 ? "00".($i + 1) : ($i + 1))), $fileChunk);
										}
							echo "<script>mail('Sending Parts � <b>".($i + 1)."</b>...', '".md5(basename($filename))."');</script>\r\n";
							flush();
							$mailed = $mailed & mail($to, $subj, $addHeads, $head);
							if (!$mailed) {return false;}
						}
				}
		}
			else
		{
			return mail($to, $subj, $zag.$file, $head) ? TRUE : FALSE;
		}

	return $mailed ? TRUE : FALSE;
}

function addAdditionalHeaders($head) {
global $un;
if($head["msg"])
  {
    $ret = "------------".$un.
           "\nContent-Type: text/plain; charset=Windows-1251\n".
           "Content-Transfer-Encoding: 8bit\n\n".$head["msg"]."\n\n";
  }
if($head["file"]["filename"])
  {
    $ret .= "------------".$un."\n".
            "Content-Type: application/octet-stream; name=\"".basename($head["file"]["filename"])."\"\n".
            "Content-Transfer-Encoding: base64\n".
            "Content-Disposition: attachment; filename=\"".basename($head["file"]["filename"])."\"\n\n".
            $head["file"]["stream"]."\n\n";
  }
return $ret;
}

function updateListInFile($list) {
    if(count($list) > 0)
      {
        foreach($list as $key => $value)
          {
              $list[$key] = serialize($value);
          }
         if(!@write_file("files.lst", implode("\r\n", $list)."\r\n") & count($list) > 0)
           {
               return FALSE;
           }
         else
           {
               return TRUE;
           }
      }
    else
      {
          return unlink("files.lst");
      }
}

function updateFtpProgress($bytesReceived) {
    global $FtpBytesTotal, $FtpBytesReceived, $FtpTimeStart, $FtpLastChunkTime, $FtpChunkSize, $FtpLast, $FtpUpload, $FtpUploadBytesSent;
      if($FtpUpload)
            {
                $FtpUploadBytesSent += $bytesReceived;
                $bytesReceived = $FtpUploadBytesSent;
            }
    $FtpBytesReceived = $bytesReceived;
    if($bytesReceived > $FtpLast + $FtpChunkSize)
      {
          $time = getmicrotime() - $FtpTimeStart;
          $chunkTime = $time - $FtpLastChunkTime;
          $FtpLastChunkTime = $time;
          $speed = round($FtpChunkSize / 1024 / $chunkTime, 2);
          # $FtpBytesReceived = $bytesReceived;
          if($bytesReceived > $FtpBytesTotal)
            {
                $percent = 100;
            }
          else
            {
                $percent = round($bytesReceived / $FtpBytesTotal * 100, 2);
            }
          $FtpLast = $bytesReceived;
          echo "<script>pr(".$percent.", '".bytesToKbOrMbOrGb($bytesReceived)."', ".$speed.")</script>\r\n";
      }
}

/*if(!defined('CRLF')) define('CRLF',"\r\n");
if(!defined("FTP_AUTOASCII")) define("FTP_AUTOASCII", -1);
if(!defined("FTP_BINARY")) define("FTP_BINARY", 1);
if(!defined("FTP_ASCII")) define("FTP_ASCII", 0);
if(!defined('FTP_FORCE')) define('FTP_FORCE', TRUE);
define('FTP_OS_Unix','u');
define('FTP_OS_Windows','w');
define('FTP_OS_Mac','m');  */

class ftp_base {
/* Public variables */
var $LocalEcho=FALSE;
var $Verbose=FALSE;
var $OS_local;

/* Private variables */
var $_lastaction=NULL;
var $_errors;
var $_type;
var $_umask;
var $_timeout;
var $_passive;
var $_host;
var $_fullhost;
var $_port;
var $_datahost;
var $_dataport;
var $_ftp_control_sock;
var $_ftp_data_sock;
var $_ftp_temp_sock;
var $_login;
var $_password;
var $_connected;
var $_ready;
var $_code;
var $_message;
var $_can_restore;
var $_port_available;

var $_error_array=array();
var $AuthorizedTransferMode=array(
FTP_AUTOASCII,
FTP_ASCII,
FTP_BINARY
);
var $OS_FullName=array(
FTP_OS_Unix => 'UNIX',
FTP_OS_Windows => 'WINDOWS',
FTP_OS_Mac => 'MACOS'
);
var $NewLineCode=array(
FTP_OS_Unix => "\n",
FTP_OS_Mac => "\r",
FTP_OS_Windows => "\r\n"
);
var $AutoAsciiExt=array("ASP","BAT","C","CPP","CSV","H","HTM","HTML","SHTML","INI","LOG","PHP","PHP3","PL","PERL","SH","SQL","TXT");

/* Constructor */
function ftp_base($port_mode=FALSE) {
$this->_port_available=($port_mode==TRUE);
$this->SendMSG("Staring FTP client class with".($this->_port_available?"":"out")." PORT mode support");
$this->_connected=FALSE;
$this->_ready=FALSE;
$this->_can_restore=FALSE;
$this->_code=0;
$this->_message="";
$this->SetUmask(0022);
$this->SetType(FTP_AUTOASCII);
$this->SetTimeout(30);
$this->Passive(!$this->_port_available);
$this->_login="anonymous";
$this->_password="anon@ftp.com";
    $this->OS_local=FTP_OS_Unix;
if(strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') $this->OS_local=FTP_OS_Windows;
elseif(strtoupper(substr(PHP_OS, 0, 3)) === 'MAC') $this->OS_local=FTP_OS_Mac;
}

// <!-- --------------------------------------------------------------------------------------- -->
// <!--       Public functions                                                                  -->
// <!-- --------------------------------------------------------------------------------------- -->
function parselisting($list) {
//Parses i line like:"drwxrwx---  2 owner group 4096 Apr 23 14:57 text"
if(preg_match("/^([-ld])([rwxst-]+)\s+(\d+)\s+([-_\w]+)\s+([-_\w]+)\s+(\d+)\s+(\w{3})\s+(\d+)\s+([\:\d]+)\s+(.+)$/i", $list, $ret)) {
$v=array(
"type"=> ($ret[1]=="-"?"f":$ret[1]),
"perms"=> 0,
"inode"=> $ret[3],
"owner"=> $ret[4],
"group"=> $ret[5],
"size"=> $ret[6],
"date"=> $ret[7]." ".$ret[8]." ".$ret[9],
"name"=> $ret[10]
);
$v["perms"]+=00400*(int)($ret[2]{0}=="rb");
$v["perms"]+=00200*(int)($ret[2]{1}=="wb");
$v["perms"]+=00100*(int)in_array($ret[2]{2}, array("x","s"));
$v["perms"]+=00040*(int)($ret[2]{3}=="rb");
$v["perms"]+=00020*(int)($ret[2]{4}=="wb");
$v["perms"]+=00010*(int)in_array($ret[2]{5}, array("x","s"));
$v["perms"]+=00004*(int)($ret[2]{6}=="rb");
$v["perms"]+=00002*(int)($ret[2]{7}=="wb");
$v["perms"]+=00001*(int)in_array($ret[2]{8}, array("x","t"));
$v["perms"]+=04000*(int)in_array($ret[2]{2}, array("S","s"));
$v["perms"]+=02000*(int)in_array($ret[2]{5}, array("S","s"));
$v["perms"]+=01000*(int)in_array($ret[2]{8}, array("T","t"));
}
return $v;
}

function SendMSG($message = "", $crlf=true) {
if ($this->Verbose) {
echo $message.($crlf?CRLF:"");
flush();
}
return TRUE;
}

function SetType($mode=FTP_AUTOASCII) {
if(!in_array($mode, $this->AuthorizedTransferMode)) {
$this->SendMSG("Wrong type");
return FALSE;
}
$this->_type=$mode;
$this->_data_prepare($mode);
$this->SendMSG("Transfer type: ".($this->_type==FTP_BINARY?"binary":($this->_type==FTP_ASCII?"ASCII":"auto ASCII") ) );
return TRUE;
}

function Passive($pasv=NULL) {
if(is_null($pasv)) $this->_passive=!$this->_passive;
else $this->_passive=$pasv;
if(!$this->_port_available and !$this->_passive) {
$this->SendMSG("Only passive connections available!");
$this->_passive=TRUE;
return FALSE;
}
$this->SendMSG("Passive mode ".($this->_passive?"on":"off"));
return TRUE;
}

function SetServer($host, $port=21, $reconnect=true) {
if(!is_long($port)) {
        $this->verbose=true;
        $this->SendMSG("Incorrect port syntax");
return FALSE;
} else {
$ip=@gethostbyname($host);
        $dns=@gethostbyaddr($host);
        if(!$ip) $ip=$host;
        if(!$dns) $dns=$host;
if(ip2long($ip) === -1) {
$this->SendMSG("Wrong host name/address \"".$host."\"");
return FALSE;
}
        $this->_host=$ip;
        $this->_fullhost=$dns;
        $this->_port=$port;
        $this->_dataport=$port-1;
}
$this->SendMSG("Host \"".$this->_fullhost."(".$this->_host."):".$this->_port."\"");
if($reconnect){
if($this->_connected) {
$this->SendMSG("Reconnecting");
if(!$this->quit(FTP_FORCE)) return FALSE;
if(!$this->connect()) return FALSE;
}
}
return TRUE;
}

function SetUmask($umask=0022) {
$this->_umask=$umask;
umask($this->_umask);
$this->SendMSG("UMASK 0".decoct($this->_umask));
return TRUE;
}

function SetTimeout($timeout=30) {
$this->_timeout=$timeout;
$this->SendMSG("Timeout ".$this->_timeout);
if($this->_connected)
if(!$this->_settimeout($this->_ftp_control_sock)) return FALSE;
return TRUE;
}

function connect() {
    $this->SendMsg('Local OS : '.$this->OS_FullName[$this->OS_local]);
if(!($this->_ftp_control_sock = $this->_connect($this->_host, $this->_port))) {
$this->SendMSG("Error : Cannot connect to remote host \"".$this->_fullhost." :".$this->_port."\"");
return FALSE;
}
$this->SendMSG("Connected to remote host \"".$this->_fullhost.":".$this->_port."\". Waiting for greeting.");
do {
if(!$this->_readmsg()) return FALSE;
if(!$this->_checkCode()) return FALSE;
$this->_lastaction=time();
} while($this->_code<200);
$this->_ready=true;
return TRUE;
}

function quit($force=false) {
if($this->_ready) {
if(!$this->_exec("QUIT") and !$force) return FALSE;
if(!$this->_checkCode() and !$force) return FALSE;
$this->_ready=false;
$this->SendMSG("Session finished");
}
$this->_quit();
return TRUE;
}

function login($user=NULL, $pass=NULL) {
if(!is_null($user)) $this->_login=$user;
else $this->_login="anonymous";
if(!is_null($pass)) $this->_password=$pass;
else $this->_password="anon@anon.com";
if(!$this->_exec("USER ".$this->_login, "login")) return FALSE;
if(!$this->_checkCode()) return FALSE;
if($this->_code!=230) {
if(!$this->_exec((($this->_code==331)?"PASS ":"ACCT ").$this->_password, "login")) return FALSE;
if(!$this->_checkCode()) return FALSE;
}
$this->SendMSG("Authentication succeeded");
$this->_can_restore=$this->restore(100);
$this->SendMSG("This server can".($this->_can_restore?"":"'t")." resume broken uploads/downloads");
return TRUE;
}

function pwd() {
if(!$this->_exec("PWD", "pwd")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return ereg_replace("^[0-9]{3} \"(.+)\" .+".CRLF, "\\1", $this->_message);
}

function cdup() {
if(!$this->_exec("CDUP", "cdup")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return true;
}

function chdir($pathname) {
if(!$this->_exec("CWD ".$pathname, "chdir")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function rmdir($pathname) {
if(!$this->_exec("RMD ".$pathname, "rmdir")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function mkdir($pathname) {
if(!$this->_exec("MKD ".$pathname, "mkdir")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function rename($from, $to) {
if(!$this->_exec("RNFR ".$from, "rename")) return FALSE;
if(!$this->_checkCode()) return FALSE;
if($this->_code==350) {
if(!$this->_exec("RNTO ".$to, "rename")) return FALSE;
if(!$this->_checkCode()) return FALSE;
} else return FALSE;
return TRUE;
}

function filesize($pathname) {
if(!$this->_exec("SIZE ".$pathname, "filesize")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return ereg_replace("^[0-9]{3} ([0-9]+)".CRLF, "\\1", $this->_message);
}

function mdtm($pathname) {
if(!$this->_exec("MDTM ".$pathname, "mdtm")) return FALSE;
if(!$this->_checkCode()) return FALSE;
$mdtm = ereg_replace("^[0-9]{3} ([0-9]+)".CRLF, "\\1", $this->_message);
$date = sscanf($mdtm, "%4d%2d%2d%2d%2d%2d");
$timestamp = mktime($date[3], $date[4], $date[5], $date[1], $date[2], $date[0]);
return $timestamp;
}

function systype() {
if(!$this->_exec("SYST", "systype")) return FALSE;
if(!$this->_checkCode()) return FALSE;
$DATA = explode(" ", $this->_message);
return $DATA[1];
}

function delete($pathname) {
if(!$this->_exec("DELE ".$pathname, "delete")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function site($command, $fnction="site") {
if(!$this->_exec("SITE ".$command, $fnction)) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function chmod($pathname, $mode) {
if(!$this->site("CHMOD ".decoct($mode)." ".$pathname, "chmod")) return FALSE;
return TRUE;
}

function restore($from) {
if(!$this->_exec("REST ".$from, "restore")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return TRUE;
}

function features() {
if(!$this->_exec("FEAT", "features")) return FALSE;
if(!$this->_checkCode()) return FALSE;
return preg_split("/[".CRLF."]+/", ereg_replace("[0-9]{3}[ -][^".CRLF."]*".CRLF, "", $this->_message), -1, PREG_SPLIT_NO_EMPTY);
}

function rawlist($arg="", $pathname="") {
return $this->_list(($arg?" ".$arg:"").($pathname?" ".$pathname:""), "LIST", "rawlist");
}

function nlist($arg="", $pathname="") {
return $this->_list(($arg?" ".$arg:"").($pathname?" ".$pathname:""), "NLST", "nlist");
}

function is_exists($pathname)
{
if (!($remote_list = $this->nlist("-a", dirname($pathname)))) {
$this->SendMSG("Error : Cannot get remote file list");
return -1;
}
reset($remote_list);
while (list(,$value) = each($remote_list)) {
if ($value == basename($pathname)) {
$this->SendMSG("Remote file ".$pathname." exists");
return TRUE;
}
}
$this->SendMSG("Remote file ".$pathname." does not exist");
return FALSE;
}

function get($remotefile, $localfile=NULL) {
if(is_null($localfile)) $localfile=$remotefile;
if (@file_exists($localfile)) $this->SendMSG("Warning: local file will be overwritten");
$fp = @fopen($localfile, "wb");
if (!$fp) {
$this->PushError("get","can't open local file", "Cannot create \"".$localfile."\"");
return FALSE;
}
$pi=pathinfo($remotefile);
if($this->_type==FTP_ASCII or ($this->_type==FTP_AUTOASCII and in_array(strtoupper($pi["extension"]), $this->AutoAsciiExt))) $mode=FTP_ASCII;
else $mode=FTP_BINARY;
if(!$this->_data_prepare($mode)) {
fclose($fp);
return FALSE;
}
if($this->_can_restore) $this->restore(0);
if(!$this->_exec("RETR ".$remotefile, "get")) {
$this->_data_close();
fclose($fp);
return FALSE;
}
if(!$this->_checkCode()) {
$this->_data_close();
fclose($fp);
return FALSE;
}
$out=$this->_data_read($mode, $fp);
fclose($fp);
$this->_data_close();
if(!$this->_readmsg()) return FALSE;
if(!$this->_checkCode()) return FALSE;
return $out;
}

function get2($remotefile, $from) {
$mode=FTP_BINARY;
if(!$this->_data_prepare($mode)) {
return FALSE;
}
if($this->_can_restore) $this->restore($from);
if(!$this->_exec("RETR ".$remotefile, "get")) {
$this->_data_close();
return FALSE;
}
if(!$this->_checkCode()) {
$this->_data_close();
return FALSE;
}
$out=$this->_data_read2();
$this->_data_close();
if(!$this->_readmsg()) return FALSE;
if(!$this->_checkCode()) return FALSE;
return $out;
}

function put($localfile, $remotefile=NULL) {
if(is_null($remotefile)) $remotefile=$localfile;
if (!@file_exists($localfile)) {
$this->PushError("put","can't open local file", "No such file or directory \"".$localfile."\"");
return FALSE;
}
$fp = @fopen($localfile, "rb");
if (!$fp) {
$this->PushError("put","can't open local file", "Cannot read file \"".$localfile."\"");
return FALSE;
}
$pi=pathinfo($localfile);
if($this->_type==FTP_ASCII or ($this->_type==FTP_AUTOASCII and in_array(strtoupper($pi["extension"]), $this->AutoAsciiExt))) $mode=FTP_ASCII;
else $mode=FTP_BINARY;
if(!$this->_data_prepare($mode)) {
fclose($fp);
return FALSE;
}
if($this->_can_restore) $this->restore(0);
if(!$this->_exec("STOR ".$remotefile, "put")) {
$this->_data_close();
fclose($fp);
return FALSE;
}
if(!$this->_checkCode()) {
$this->_data_close();
fclose($fp);
return FALSE;
}
$ret=$this->_data_write($mode, $fp);
fclose($fp);
$this->_data_close();
if(!$this->_readmsg()) return FALSE;
if(!$this->_checkCode()) return FALSE;
return $ret;
}

// <!-- --------------------------------------------------------------------------------------- -->
// <!--       Private functions                                                                 -->
// <!-- --------------------------------------------------------------------------------------- -->
function _checkCode() {
return ($this->_code<400 and $this->_code>0);
}

function _list($arg="", $cmd="LIST", $fnction="_list") {
if(!$this->_data_prepare()) return FALSE;
if(!$this->_exec($cmd.$arg, $fnction)) {
$this->_data_close();
return FALSE;
}
if(!$this->_checkCode()) {
$this->_data_close();
return FALSE;
}
$out=$this->_data_read();
$this->_data_close();
if(!$this->_readmsg()) return FALSE;
if(!$this->_checkCode()) return FALSE;
if($out === FALSE ) return FALSE;
$out=preg_split("/[".CRLF."]+/", $out, -1, PREG_SPLIT_NO_EMPTY);
$this->SendMSG(implode($this->NewLineCode[$this->OS_local], $out));
return $out;
}

// <!-- --------------------------------------------------------------------------------------- -->
// <!-- Partie : gestion des erreurs                                                            -->
// <!-- --------------------------------------------------------------------------------------- -->
// Genere une erreur pour traitement externe a la classe
function PushError($fctname,$msg,$desc=false){
$error=array();
$error['time']=time();
$error['fctname']=$fctname;
$error['msg']=$msg;
$error['desc']=$desc;
if($desc) $tmp=' ('.$desc.')'; else $tmp='';
$this->SendMSG($fctname.': '.$msg.$tmp);
return(array_push($this->_error_array,$error));
}

// Recupere une erreur externe
function PopError(){
if(count($this->_error_array)) return(array_pop($this->_error_array));
else return(false);
}
}

$mod_sockets=TRUE;
if (!extension_loaded('sockets')) {
    $prefix = (PHP_SHLIB_SUFFIX == 'dll') ? 'php_' : '';
    if(!@dl($prefix . 'sockets.' . PHP_SHLIB_SUFFIX)) $mod_sockets=FALSE;
}

$mod_sockets=TRUE;
if (!extension_loaded('sockets')) {
    $prefix = (PHP_SHLIB_SUFFIX == 'dll') ? 'php_' : '';
    if(!@dl($prefix . 'sockets.' . PHP_SHLIB_SUFFIX)) $mod_sockets=FALSE;
}

class ftp  extends ftp_base {
function ftp($verb=FALSE, $le=FALSE) {
$this->LocalEcho = $le;
$this->Verbose = $verb;
$this->ftp_base();
}

// <!-- --------------------------------------------------------------------------------------- -->
// <!--       Private functions                                                                 -->
// <!-- --------------------------------------------------------------------------------------- -->

function _settimeout($sock) {echo"===";
/*if(!@stream_set_timeout($sock, $this->_timeout)) {
$this->PushError('_settimeout','socket set send timeout');
$this->_quit();
return FALSE;
}
*/return TRUE;
}

function _connect($host, $port) {
$this->SendMSG("Creating socket");
$sock = @fsockopen($host, $port, $errno, $errstr, $this->_timeout);
if (!$sock) {
$this->PushError('_connect','socket connect failed', $errstr." (".$errno.")");
return FALSE;
}
$this->_connected=true;
return $sock;
}

function _readmsg($fnction="_readmsg"){
if(!$this->_connected) {
$this->PushError($fnction, 'Connect first');
return FALSE;
}
$result=true;
$this->_message="";
$this->_code=0;
$go=true;
do {
$tmp=@fgets($this->_ftp_control_sock, 512);
if($tmp===false) {
$go=$result=false;
$this->PushError($fnction,'Read failed');
} else {
$this->_message.=$tmp;
//for($i=0; $i<strlen($this->_message); $i++)
//if(ord($this->_message[$i])<32) echo "#".ord($this->_message[$i]); else echo $this->_message[$i];
//echo CRLF;
if(preg_match("/^([0-9]{3})(-(.*".CRLF.")+\\1)? [^".CRLF."]+".CRLF."$/", $this->_message, $regs)) $go=false;
}
} while($go);
if($this->LocalEcho) echo "GET < ".rtrim($this->_message, CRLF).CRLF;
$this->_code=(int)$regs[1];
return $result;
}

function _exec($cmd, $fnction="_exec") {
if(!$this->_ready) {
$this->PushError($fnction,'Connect first');
return FALSE;
}
if($this->LocalEcho) echo "PUT > ",$cmd,CRLF;
$status=@fputs($this->_ftp_control_sock, $cmd.CRLF);
if($status===false) {
$this->PushError($fnction,'socket write failed');
return FALSE;
}
$this->_lastaction=time();
if(!$this->_readmsg($fnction)) return FALSE;
return TRUE;
}

function _data_prepare($mode=FTP_ASCII) {
if($mode==FTP_BINARY) {
if(!$this->_exec("TYPE I", "_data_prepare")) return FALSE;
} else {
if(!$this->_exec("TYPE A", "_data_prepare")) return FALSE;
}
if($this->_passive) {
if(!$this->_exec("PASV", "pasv")) {
$this->_data_close();
return FALSE;
}
if(!$this->_checkCode()) {
$this->_data_close();
return FALSE;
}
$ip_port = explode(",", ereg_replace("^.+ \\(?([0-9]{1,3},[0-9]{1,3},[0-9]{1,3},[0-9]{1,3},[0-9]+,[0-9]+)\\)?.*".CRLF."$", "\\1", $this->_message));
$this->_datahost=$ip_port[0].".".$ip_port[1].".".$ip_port[2].".".$ip_port[3];
            $this->_dataport=(((int)$ip_port[4])<<8) + ((int)$ip_port[5]);
$this->SendMSG("Connecting to ".$this->_datahost.":".$this->_dataport);
$this->_ftp_data_sock=@fsockopen($this->_datahost, $this->_dataport, $errno, $errstr, $this->_timeout);
if(!$this->_ftp_data_sock) {
$this->PushError("_data_prepare","fsockopen fails", $errstr." (".$errno.")");
$this->_data_close();
return FALSE;
}
else $this->_ftp_data_sock;
} else {
$this->SendMSG("Only passive connections available!");
return FALSE;
}
return TRUE;
}

function _data_read($mode=FTP_ASCII, $fp=NULL) {
$NewLine=$this->NewLineCode[$this->OS_local];
if(is_resource($fp)) $out=0;
else $out="";
if(!$this->_passive) {
$this->SendMSG("Only passive connections available!");
return FALSE;
}
if($mode!=FTP_BINARY) {
while (!feof($this->_ftp_data_sock)) {
$tmp=fread($this->_ftp_data_sock, 4096);
$line.=$tmp;
if(!preg_match("/".CRLF."$/", $line)) continue;
$line=rtrim($line,CRLF).$NewLine;
if(is_resource($fp))
  {
      $out+=fwrite($fp, $line, strlen($line));
      updateFtpProgress($out);
  }
else
  {
      $out.=$line;
  }
$line="";
}
} else {
while (!feof($this->_ftp_data_sock)) {
$block=fread($this->_ftp_data_sock, 4096);
if(is_resource($fp))
  {
      $out+=fwrite($fp, $block, strlen($block));
      updateFtpProgress($out);
  }
else
  {
      $out.=$line;
  }
}
}
return $out;
}

function _data_read2() {
$NewLine=$this->NewLineCode[$this->OS_local];
$out=0;
if(!$this->_passive) {
$this->SendMSG("Only passive connections available!");
return FALSE;
}
while (!feof($this->_ftp_data_sock)) {
$block=fread($this->_ftp_data_sock, 4096);
$out+=strlen($block);
echo $block;
}
return $out;
}

function _data_write($mode=FTP_ASCII, $fp=NULL) {
$NewLine=$this->NewLineCode[$this->OS_local];
if(is_resource($fp)) $out=0;
else $out="";
if(!$this->_passive) {
$this->SendMSG("Only passive connections available!");
return FALSE;
}
if(is_resource($fp)) {
while(!feof($fp)) {
$line=fgets($fp, 4096);
if($mode!=FTP_BINARY) $line=rtrim($line, CRLF).CRLF;
do {
if(($res=@fwrite($this->_ftp_data_sock, $line))===FALSE)
  {
      $this->PushError("_data_write","Can't write to socket");
      return FALSE;
  }
else
  {
      updateFtpProgress(strlen($line));
  }
$line=substr($line, $res);
}while($line!="");
}
} else {
if($mode!=FTP_BINARY) $fp=rtrim($fp, $NewLine).CRLF;
do {
if(($res=@fwrite($this->_ftp_data_sock, $fp))===FALSE)
  {
      $this->PushError("_data_write","Can't write to socket");
      return FALSE;
  }
else
  {
      updateFtpProgress(strlen($fp));
  }
$fp=substr($fp, $res);
}while($fp!="");
}
return TRUE;
}

function _data_close() {
@fclose($this->_ftp_data_sock);
$this->SendMSG("Disconnected data from remote host");
return TRUE;
}


function _quit($force=FALSE) {
if($this->_connected or $force) {
@fclose($this->_ftp_control_sock);
$this->_connected=false;
$this->SendMSG("Socket closed");
}
}
}

function _cmp_list_enums($a,$b)
{return strcmp($a["name"],$b["name"]); }

function _create_list()
{ global $list,$_COOKIE,$systemfile,$show_all;
  $glist = array();
  if(($show_all === true) & ($_COOKIE["showAll"] == 1))
   {
    $dir = dir("./");
    while(false !== ($file = $dir->read()))
     {
      if($file != "." & $file != ".." & (!in_array($file,$systemfile)) & is_file("./".$file))
       {
        $file = "./".$file;
        $time = filectime($file);
        while(isset($glist[$time])) $time++;
        $glist[$time] = array("name" => realpath($file),
                              "size" => bytesToKbOrMbOrGb(filesize($file)),
                              "date" => $time);
       }
     }
     $dir->close();
     @uasort($glist,"_cmp_list_enums");
   } else
   {
     if(@file_exists("files.lst"))
      {
       $glist = file("files.lst");
       foreach($glist as $key => $record)
        {
         foreach(unserialize($record) as $field => $value)
          {
           $listReformat[$key][$field] = $value;
           if($field == "date") $date = $value;
          }
         $glist[$date] = $listReformat[$key];
         unset($glist[$key], $glistReformat[$key]);
        }
       }
    }
  $list = $glist;
};

 //*********************************************************//
 //* Encrypts and Decrypts a chain.                        *//
 //*-------------------------------------------------------*//
 //* Original in VB for:    Kelvin C. Perez.               *//
 //* E-Mail:                kelvin_perez@msn.com           *//
 //* WebSite:               http://home.coqui.net/punisher *//
 //*+++++++++++++++++++++++++++++++++++++++++++++++++++++++*//
 //* Programmed in PHP for: Heriberto Mantilla Santamar�a. *//
 //* E-Mail:                heri_05-hms@mixmail.com        *//
 //* WebSite:               www.geocities.com/hackprotm/   *//
 //*.......................................................*//
 //* IMPORTANT NOTE                                        *//
 //*-------------------------------------------------------*//
 //* Feel free to use this class in your pages, provided   *//
 //* ALL credits remain intact. Only dishonorable thieves  *//
 //* download code that REAL programmers work hard to write*//
 //* and freely share with their programming peers, then   *//
 //* remove the comments and claim that they wrote the     *//
 //* code.                                                 *//
 //*-------------------------------------------------------*//
 //*         All Rights Reserved HACKPRO TM � 2005         *//
 //*********************************************************//
/*
 class EnDecryptText
 {
  function Encrypt_Text($cText)
  {$eText = $cText;
   $nEncKey = intval((100 * $this->Rnd()) + 1);
   $nCharSize = 0;
   $nUpperBound = 10;
   $nLowerBound = 5;
   $nCharSize = intval(($nUpperBound - $nLowerBound + 1) * $this->Rnd() + $nLowerBound);
   $cCharSize = $this->fEncryptedKeySize($nCharSize);
   $cEncKey = $this->NumToString($nEncKey, $nCharSize);
   $cEncryptedText = '';
   $nTextLenght = strlen($eText);
   for($nCounter = 1; $nCounter <= $nTextLenght; $nCounter++)
   {
    $cChar = $this->Mid($eText, $nCounter, 1);
    $nChar = ord($cChar) * $nEncKey;
    $cChar2 = $this->NumToString($nChar, $nCharSize);
    $cEncryptedText .= $cChar2;
   }
   $nLeft = intval(strlen($cEncryptedText) / 2);
   $cLeft = $this->strleft($cEncryptedText, $nLeft);
   $nRight = strlen($cEncryptedText) - $nLeft;
   $cRight = $this->strright($cEncryptedText, $nRight);
   $cDummy = $this->CreateDummy();
   $this->InsertInTheMiddle($cEncryptedText, $cEncKey);
   $this->InsertInTheMiddle($cEncryptedText, $cCharSize);
   $cEncryptedText = $this->CreateDummy() . $cEncryptedText . $this->CreateDummy();
   return $cEncryptedText;
  }

  function Decrypt_Text($cText)
  {$cTempText = $cText;
   $cDecryptedText = '';
   $cText = '';
   for($nCounter = 1; $nCounter <= strlen($cTempText); $nCounter++)
   {$cChar = $this->Mid($cTempText, $nCounter, 1);
    if ($this->IsNumeric($cChar) == true)
     $cText .= $cChar;
    else
     $cText .= '0';
   }
   $cText = $this->strleft($cText, strlen($cText) - 4);
   $cText = $this->strright($cText, strlen($cText) - 4);
   $nCharSize = 0;
   $this->Extract_Char_Size($cText, $nCharSize);
   $this->Extract_Enc_Key($cText, $nCharSize, $nEncKey);
   $nTextLenght = strlen($cText);
   $nCounter = 1;
   do
   {
    $cChar = $this->Mid($cText, $nCounter, $nCharSize);
    $nChar = $this->Val($cChar);
    if ($nEncKey > 0) $nChar2 = $nChar / $nEncKey;
    $cChar2 = chr($nChar2);
    $cDecryptedText .= $cChar2;
    $nCounter += $nCharSize;
   }while ($nCounter <= strlen($cText));
   return trim($cDecryptedText);
  }

  function Extract_Char_Size(&$cText, &$nCharSize)
  {
   $nLeft = intval(strlen($cText) / 2);
   $cLeft = $this->strleft($cText, $nLeft);
   $nRight = strlen($cText) - $nLeft;
   $cRight = $this->strright($cText, $nRight);
   $nKeyEnc = $this->Val($this->strright($cLeft, 2));
   $nKeySize = $this->Val($this->strleft($cRight, 2));
   if ($nKeyEnc >= 5)
    $nCharSize = $nKeySize + $nKeyEnc;
   else
    $nCharSize = $nKeySize - $nKeyEnc;
   $cText = $this->strleft($cLeft, strlen($cLeft) - 2) . $this->strright($cRight, strlen($cRight) - 2);
  }

  function Extract_Enc_Key(&$cText, $nCharSize, &$nEncKey)
  {$cEncKey = '';
   $nLenght = strlen($cText) - $nCharSize;
   $nLeft = intval($nLenght / 2);
   $cLeft = $this->strleft($cText, $nLeft);
   $nRight = $nLenght - $nLeft;
   $cRight = $this->strright($cText, $nRight);
   $cEncKey = $this->Mid($cText, $nLeft + 1, $nCharSize);
   $nEncKey = $this->Val(trim($cEncKey));
   $cText = $cLeft . $cRight;
  }

  function fEncryptedKeySize($nKeySize)
  {$nLowerBound = 0;
   $nKeyEnc = intval(($nKeySize - $nLowerBound + 1) * $this->Rnd() + $nLowerBound);
   if ($nKeyEnc >= 5)
    $nKeySize = $nKeySize - $nKeyEnc;
   else
    $nKeySize = $nKeySize + $nKeyEnc;
   return $this->NumToString($nKeyEnc, 2) . $this->NumToString($nKeySize, 2);
  }

  function NumToString($nNumber, $nZeros)
  {
   $cNumber = trim(strval($nNumber));
   $nLenght = strlen($cNumber);
   if ($nZeros < $nLenght) $nZeros = 0;
   $nUpperBound = 122;
   $nLowerBound = 65;
   for($nCounter = 1; $nCounter <= ($nZeros - $nLenght); $nCounter++)
   {
    $lCreated = false;
    do
    {$nNumber = intval(($nUpperBound - $nLowerBound + 1) * $this->Rnd() + $nLowerBound);
     if (($nNumber > 90) && ($nNumber < 97))
      $lCreated = false;
     else
      $lCreated = true;
    }while ($lCreated == false);
    $cChar = chr($nNumber);
    $cNumber = $cChar . $cNumber;
   }
   return $cNumber;
  }

  function InsertInTheMiddle(&$cSourceText, $cTextToInsert)
  {
   $nLeft = intval(strlen($cSourceText) / 2);
   $cLeft = $this->strleft($cSourceText, $nLeft);
   $nRight = strlen($cSourceText) - $nLeft;
   $cRight = $this->strright($cSourceText, $nRight);
   $cSourceText = $cLeft . $cTextToInsert . $cRight;
  }

  function CreateDummy()
  {$nUpperBound = 122;
   $nLowerBound = 48;
   for($nCounter = 1; $nCounter <= 4; $nCounter++)
   {$lCreated = false;
    do
    {$nDummy = intval(($nUpperBound - $nLowerBound + 1) * $this->Rnd() + $nLowerBound);
     if ((($nDummy > 57) && ($nDummy < 65)) || (($nDummy > 90) && ($nDummy < 97)))
      $lCreated = false;
     else
      $lCreated = true;
    }while ($lCreated == false);
    $cDummy .= chr($nDummy);
   }
   return $cDummy;
  }


  function strleft($tmp, $nLeft)
  {$len = strlen($tmp);
   if ($nLeft == 0)
    $str = '';
   else if ($nLeft < $len)
    $str = $this->Mid($tmp, 1, $nLeft);
   return $str;
  }

  function strright($tmp, $nRight)
  {$len = strlen($tmp);
   if ($nRight == 0)
    $str = '';
   else if ($nRight < $len)
    $str = $this->Mid($tmp, $len - $nRight + 1, $len);
   return $str;
  }

  function Mid($tmp, $start, $length)
  {$str = substr($tmp, $start - 1, $length);
   return $str;
  }

  function Rnd()
  {srand();
   do
   {$tmp = abs(tan(rand()));
   }while (($tmp > "1") || ($tmp < "0"));
   $tmp = $this->Mid($tmp, 1, 8);
   return $tmp;
  }

  function Val($tmp)
  {$length = strlen($tmp);
   $tmp2 = 0;
   for ($i = 1; $i <= $length; $i++)
   {$tmp1 = $this->Mid($tmp, $i, 1);
    if ($this->IsNumeric($tmp1) == 1)
    {$tmp2 .= $tmp1;}
   }
   return intval($tmp2);
  }

  function IsNumeric($cChar)
  {$tmp = ord($cChar);
   if (($tmp < 48) || ($tmp > 57))
    $tmp = false;
   else
    $tmp = true;
   return $tmp;
  }
 }
*/
?>