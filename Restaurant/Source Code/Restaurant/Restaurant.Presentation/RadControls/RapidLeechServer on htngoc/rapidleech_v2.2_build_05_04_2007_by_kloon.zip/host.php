<?php
if (!defined('RAPIDLEECH')) {die("not load primary script");}

if(in_array($Url["host"],array("www.cyberupload.com","www.megashares.com","d01.megashares.com",
    							 "zupload.com","www.supashare.com","www.sendover.com","friendlyshare.de","dvb-upload.com")))
      {
         html_error("This service is not supported");
      }
    
    #ftp					- ok
    #direct					- ok
    
    #rapidshare.de			- ok
    #rapidshare.com			- ok
    #www.megaupload.com		- ok
    #www.megarotic.com		- ok
    #filefactory.com		- ok
    #www.filefactory.com	- ok
    #sr1.mytempdir.com		- ok
    #www.mytempdir.com		- ok
    #getfile.biz			- ok
    #files.to				- ok
    #d.turboupload.com		- ok
    #up-file.com			- ok
    #www.up-file.com		- ok
    #depositfiles.com		- ok
    #ultrashare.net			- ok
    #webfile.ru				- ok
    #slil.ru				- ok
    #zalil.ru				- ok
    #www.upload2.net		- down
    #www.rapidupload.com	- ok (single file name)
    #momoshare.com			- ok
    #www.sendspace.com		- ok
    #www.filecache.de		- ok
    #www.verzend.be			- ok
    #www.savefile.com		- ok
    #hyperupload.com		- ok
    #www.uploading.com		- ok
    #oxyshare.com			- ok
    #www.oxyshare.com		- ok
    
    if(!in_array($Url["host"], array("rapidshare.de", "rapidshare.com", "www.rapidupload.com", "momoshare.com", "www.user.kz", "www.savefile.com", "hyperupload.com", "filefactory.com", "www.filefactory.com",
									"www.megarotic.com", "www.megaupload.com", "www.sexuploader.com", "www.upload2.net", "sr1.mytempdir.com", "www.mytempdir.com","www.sendspace.com", "www.oxyshare.com", "oxyshare.com",
									"getfile.biz", "webfile.ru", "slil.ru", "zalil.ru", "d.turboupload.com", "files.to", "up-file.com", "www.up-file.com", "storeandserve.com", "www.speedshare.org",
									"depositfiles.com", "ultrashare.net", "uploadport.com", "www.uploadport.com", "www.uploading.com", "www.filecache.de", "www.verzend.be")))
		{
			echo "<html>\n<head>\n<title>Downloading $LINK</title>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\n</head>\n<body>\n";
			
			$Href=$LINK;
			
			$Url = parse_url($Href);
			$FileName = !$FileName ? basename($Url["path"]) : $FileName;
              
			$auth = ($Url["user"] && $Url["pass"]) ? "&auth=".base64_encode($Url["user"].":".$Url["pass"]) : "";
			
			insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").$auth.($pauth ? "&pauth=$pauth" : ""));
			exit;
		}
			else
		{
		echo "<html>\n<head>\n<title>Downloading $LINK</title>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\n</head>\n<body>\n";
		switch ($Url[host])
			{
			case "hyperupload.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_notpresent($page, 'var filename =', 'Error decoding page');
				
				$Href = "http://hyperupload.com/dload/".cut_str($page, "var uid = '", "';")."_".cut_str($page, "var brbrbr = '", "';")."/".cut_str($page, "var filename = '", "';");
				$Url = parse_url($Href);
				$FileName = !$FileName ? basename($Url["path"]) : $FileName;

				$countDown = 30;
				insert_timer($countDown, "File is being prepared.","",true);
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.savefile.com":
				$fid=basename($Url["path"]);
				
				$firstpage="http://www.savefile.com/files.php?fid=$fid";
				$Url=parse_url($firstpage);
				$Referer=$LINK;
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page, 'File not found');
				
				$Cookie=GetCookies($page);
				
				$finalpage="http://www.savefile.com/download.php?fid=$fid";
				$Referer=$firstpage;
				
				$Url = parse_url($finalpage);
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $Cookie, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_notpresent($page, 'Your download should begin shortly', 'Error retrieving direct link');
				
				$Href = "http://dl".cut_str($page, '<a href="http://dl', '">');
				$Url = parse_url($Href);
				$FileName = basename($Url["path"]);
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
					
			case "www.uploading.com":
				$langcookie="setlang=en; expires=Wed, 22 Aug 2007 23:24:01 GMT; path=/; domain=.uploading.com";
				if ($_GET["step"] == "1")
					{
					$post = array();
					$post["saff"]="0";
      				$post["s"]="0";
      				$post["nextstep"]="1";
      				$post["imgcode"] = $_GET["imgcode"];
      				$post["cs_data"] = urldecode($_GET["cs_data"]);
      				
      				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $langcookie, $post, 0, $_GET["proxy"],$pauth);
      				
      				is_page($page);
      				is_present($page,'Please enter valid confirm code, shown above','Please enter valid confirm code');
      				is_present($page,'Sorry, but you seem to have bumped into an invalid link');
      				
      				$findvar = cut_str($page,"'Please wait '+","+'");
      				$countDownLeft = "var ".$findvar."=";
      				$countDown = trim(cut_str($page, $countDownLeft, ";"));
      				$countDown = $countDown ? $countDown : 50;
      				
      				$linkblock = cut_str($page,'<div id="linkblock"','</div>');
      				$linkblock = urldecode(cut_str($page,"une"."scape('","')"));
      				
      				if (!$linkblock)
      					{
      					html_error('Service changed protection method');
      					}
      				
      				$Href = cut_str($linkblock,'<a href="','"');
					if (!$Href) { html_error('Error getting direct link'); }
					//$Href=$Url["scheme"]."://".$Url["host"]."/en/get".$Href;
					
					insert_timer($countDown, "File is being prepared.","",true);
					
					$Url = parse_url($Href);
					//$FileName = !$FileName ? basename($Url["path"]) : $FileName;
					
      				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $langcookie, 0, 0, $_GET["proxy"],$pauth);
      				is_page($page);
      				is_notpresent($page,'Location:','Error retrieving link');
      				
      				$Referer = $Href;
      				$Href = trim(cut_str($page,'Location:',"\n"));
					$Url = parse_url($Href);
					$FileName = "attachment";
					if (!$Href)
						{
						html_error('Error getting direct link');
						}

					insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
					}
				else
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, $langcookie, 0, 0, $_GET["proxy"],$pauth);
					
					is_page($page);
					is_present($page,'Sorry, but you seem to have bumped into an invalid link');
					
					if (stristr($page, 'unescape'))
						{
						if (stristr($page, '<div id="linkblock"'))
							{
							$linkblock = cut_str($page,'<div id="linkblock"','</div>');
							$linkblock = urldecode(cut_str($linkblock,"une"."scape('","')"));
							if (!$linkblock)
								{
								html_error('Service changed protection method');
								}
							
							$Referer = $Href;
							$Href = cut_str($linkblock,'<a href="','"');
							if (!$Href)
								{
								html_error('Error getting direct link');
								}
							
							$Url = parse_url($Href);
							$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $langcookie, 0, 0, $_GET["proxy"],$pauth);
							is_page($page);
							is_notpresent($page,'Location:','Error retrieving link');
							
							$Referer = $Href;
							$Href = trim(cut_str($page,'Location:',"\n"));
							$Url = parse_url($Href);
							$FileName = "attachment";
							if (!$Href)
								{
								html_error('Error getting direct link');
								}
							
							insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
							}
						else
							{
							is_present($page, "All download slots assigned to your country", "All download slots assigned to your country are in use. Please try again later.");
							
							$codeblock = cut_str($page,'<div id="codeblock"','</div>');
							$codeblock = urldecode(cut_str($codeblock,"une"."scape('","'))"));
							
							$cs_data = cut_str($codeblock,'name="cs_data" value="','">');
							if (!$cs_data)
								{
								html_error("Error decoding page");
								}
							
							$access_image_url = cut_str($codeblock,'<img border="0" src="','">');
							if (!$access_image_url)
								{
								html_error("Error getting image url");
								}
							
							$Href = trim(cut_str($codeblock, 'action="','"'));
							if (!$Href)
								{
								html_error("Error getting download link");
								}
							
							print "<form action=\"$PHP_SELF\" method=\"post\">\n";
							print "<input type=\"hidden\" name=\"link\" value=\"".urlencode($Href)."\">\n<input type=\"hidden\" name=\"referer\" value=\"".urlencode($Referer)."\">\n<input type=\"hidden\" name=\"cs_data\" value=\"".urlencode($cs_data)."\">\n<input type=\"hidden\" name=\"step\" value=\"1\">\n";
							print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\n";
							print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\n";
							print "<h4>Enter <img src=\"$access_image_url\"> here: <input type=\"text\" name=\"imgcode\" size=\"4\" maxlength=\"5\">  <input type=\"submit\" value=\"Download File\"></h4>\n";
							print "</form>\n</body>\n</html>";
							flush();
							}
						}
					else
						{
						is_notpresent($page,'name="cs_data" value="','Error decoding first page.');
						
						$cs_data = cut_str($page,'name="cs_data" value="','">');

						$post = array();
						$post["cs_data"] = $cs_data;
						$post["saff"] = "0";
						$post["s"] = "0";
						$post["nextstep"] = "1";
						//$post["submit"] = "Free";
						
						$Href = $Url["scheme"]."://".$Url["host"]."/en".$Url["path"].($Url["query"] ? "?".$Url["query"] : "");
						$Url = parse_url($Href);
						
						$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $langcookie, $post, 0, $_GET["proxy"],$pauth);
						
						is_present($page, "All download slots assigned to your country", "All download slots assigned to your country are in use. Please try again later.");
						
						$linkblock = cut_str($page,'<div id="linkblock"','</div>');
						$linkblock = urldecode(cut_str($linkblock,"une"."scape('","'))"));
						
						$cs_data = cut_str($linkblock,'name="cs_data" value="','">');
						if (!$cs_data)
							{
							html_error("Error decoding page");
							}
						
						$access_image_url = cut_str($linkblock,'<img border="0" src="','">');
						if (!$access_image_url)
							{
							html_error("Error getting image url");
							}
						
						print "<form action=\"$PHP_SELF\" method=\"post\">\n";
						print "<input type=\"hidden\" name=\"link\" value=\"".urlencode($Href)."\">\n<input type=\"hidden\" name=\"referer\" value=\"".urlencode($Referer)."\">\n<input type=\"hidden\" name=\"cs_data\" value=\"".urlencode($cs_data)."\">\n<input type=\"hidden\" name=\"step\" value=\"1\">\n";
						print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\n";
						print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\n";
						print "<h4>Enter <img src=\"$access_image_url\"> here: <input type=\"text\" name=\"imgcode\" size=\"3\" maxlength=\"4\">  <input type=\"submit\" value=\"Download File\"></h4>\n";
						print "</form>\n</body>\n</html>";
						flush();
						}
					}
				exit;
			break;
			
			case "oxyshare.com":
			case "www.oxyshare.com":
				$Url["host"] = "www.oxyshare.com";
								
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page, "The file you are trying to download has been vanished off");
				is_notpresent($page, "action=/got/", "Service changed protection method");
				
				$Referer = $LINK;
				$Href = $Url["scheme"]."://".$Url["host"]."/got/".trim(cut_str($page, "action=/got/", ">"));
				$Url = parse_url($Href);
				
				unset($post);
				$post["getfile"] = "Fast and Extreme";
				$post["fname"] = trim(cut_str($page, 'name="fname" value="', '">'));;
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, $post, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_notpresent($page, "dnl1+", "Service changed protection method");
				
				$findvar = cut_str($page, 'Please, wait "+','+" seconds');
				$countDown = trim(cut_str($page, "var ".$findvar."=", ";"));
				
				$Referer = $Href;
				$Href = $Url["scheme"]."://".$Url["host"]."/".trim(cut_str($page, 'dnl1+ "/', '";'));
				$Url = parse_url($Href);
				if (!$Href)
					{
					html_error("Error getting download link");
					}
				
				insert_timer($countDown, "File is being prepared.","",true);
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				is_notpresent($page,'Location:','Error retrieving link');
				
				$Referer = $Href;
				$Href = trim(cut_str($page,'Location:',"\n"));
				$Url = parse_url($Href);
				$FileName = !$FileName ? basename($Url["path"]) : $FileName;
				if (!$Href)
					{
					html_error('Error getting direct link');
					}
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				/*
				if ($_GET["step"] == "1")
					{
					unset($post);
					$post["txt"] = trim($_GET["txt"]);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, $post, 0, $_GET["proxy"],$pauth);
					is_page($page);
					print $page;
					}
				else
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					while (stristr($page, "Location:"))
						{
						$Referer = $LINK;
						$LINK = trim(cut_str($page, "Location:", "\n"));
						$Url = parse_url($LINK);
						
						$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
						is_page($page);
						}
					
					if (stristr($page, "enter the code below to access"))
						{
						//$Href = $Url["scheme"]."://".$Url["host"].":".$Url["port"]."/";
						$access_image_url = $PHP_SELF."?image=".urlencode($Url["scheme"]."://".$Url["host"].":".$Url["port"]."/img.php?")."&referer=".urlencode($LINK);
						
						print "<form action=\"$PHP_SELF\" method=\"post\">\r\n";
						print "<input type=\"hidden\" name=\"link\" value=\"".urlencode($LINK)."\">\r\n<input type=\"hidden\" name=\"referer\" value=\"".urlencode($LINK)."\">\r\n<input type=\"hidden\" name=\"step\" value=\"1\">\r\n";
						print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\r\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\r\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\r\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\r\n";
						print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\r\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\r\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\r\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\r\n";
						print "<h4>Enter&nbsp;<img src=\"$access_image_url\">&nbsp;here:&nbsp;<input type=\"text\" name=\"txt\" size=\"5\" maxlength=\"5\">&nbsp;<input type=\"submit\" value=\"Download File\"></h4>\r\n";
						print "</form>\n</body>\n</html>";
						flush();
						}
					else
						{
						
						}
					}
				*/
				exit;
			break;
			
			case "www.sendspace.com":
				if (!file_exists("sendspace.php"))
					{
						html_error("Not support this server. Required library not found.");
					}
				require_once "sendspace.php";
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"], 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page,"There are no free download slots available");
				is_present($page,"Sorry, the file you requested is not available");
         		//$countDown=trim(cut_str($page,"var count = ",";"));
				//insert_timer($countDown, "File is being prepared.","",true);

				$code_enc = cut_str($page,'<script>function enc(text){','}</script>');
				if (!$code_enc)
					{
						html_error('Error getting link');
					}
				
				$par1 = cut_str($code_enc,'Array();',';');
				list($tmp,$par1) = explode('=',$par1);
				
				$par2 = cut_str($code_enc,"='","';");
				
				$dec_text = cut_str($page,"enc(base64ToText('","'));");
				
				$d64text = sendspace_base64ToText($dec_text);
				$urlnew = sendspace_enc($par1,$par2,$d64text);

				is_notpresent($urlnew,'href="','Error decrypting URL page');
				
				$Href = cut_str($urlnew,'href="','">');
				if (!$Href)
					{
						html_error('Error decrypting URL page');
					}
					
				$Url = parse_url($Href);
				$FileName = !$FileName ? basename($Url["path"]) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.user.kz":
				$query=$Url["query"];
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_notpresent($page,'name=fileid','Request file not found');

				$Href = "http://www.user.kz/files/index.php?$query&act=1";
				unset($post);
				$post["fileid"] = $query;
				
				$Url = parse_url($Href);
				$FileName = "attachment";
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&post=".urlencode(serialize($post))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.verzend.be":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_notpresent($page,'var downloadlink = "',"Error request download page");
				is_present($page,'File Expired');
				is_present($page,'File Deleted');
				
				$Href=cut_str($page,'var downloadlink = "','"');
				
				if (!$Href) { html_error('Error getting direct link'); }

				$var_c=cut_str($page,'"Please wait " + ',' + " seconds');
				
				$countDown=cut_str($page,"var $var_c = ",';');
				insert_timer($countDown, "File is being prepared.","",true);
				
				$Url = parse_url($Href);
				$Referer = $LINK;
				$FileName = !$FileName ? basename($Url["path"]) : $FileName;
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "momoshare.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				is_notpresent($page,"You are downloading","Error get first page");
				is_notpresent($page,'You are downloading <span class="textred">',"Error get first page");
				$FileName=cut_str($page,'You are downloading <span class="textred">','</span>');
				if (!$FileName) { html_error('Error get file name'); }				
				
				unset($post1);
				$fileid=cut_str($page,'id="ref" value="','"');
				$post1["ref"]=$fileid;
				$post1["Submit"]="Continue";
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, "/index.php" ,0 , 0, $post1, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
         		$countDown=trim(cut_str($page,"var _timeout = ",";"));
				insert_timer($countDown, "File is being prepared.","",true);
				
				is_notpresent($page,"Please wait for $countDown seconds","Counter is not found");
				
				unset($post2);
				$post2["permission"]="yes";
				$post2["Submitit"]="Download";
				
				$Referer="http://momoshare.com/index.php";
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, "/download2.php?file=$fileid" ,0 , 0, $post2, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page,"URL=err.php","We're sorry, but your maximum file download limit is reached<br>Please wait for 5 minutes and try again");
				
				$Referer="http://momoshare.com/index.php";
				$Href=trim(cut_str($page,'Location: ',"\n"));
											
				$Url = parse_url($Href);
				$FileName = basename($url["path"]);
				if (!$FileName) {html_error('Error get direct link');}
				$tmp = explode("/", $Href);

				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path])."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.rapidupload.com":
      	    	$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				is_notpresent($page,"ready.gif","File not ready or not fond");
				
				if (!cut_str($page,'<a href="file.php?filepath=','"'))
					{
						html_error('Error get link ID');
					}
					
				$Href="http://www.rapidupload.com/dl.php?id=".cut_str($page,'<a href="file.php?filepath=','"');

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = "attachment";
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.filecache.de":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page,'<strong>Diese Datei wurde zum','File has been deleted');
				is_present($page,'Die von Ihnen angeforderte Datei existiert nicht mehr auf unserem System','File not found');
				
				$fl_array = array_pop(preg_grep('/alt="Download"/', explode("\n",$page)));
				is_notpresent($fl_array,'alt="Download"','Error retrieving link'.$page);
				
				$Href=cut_str($fl_array,'<a href="','"');
				if (!$Href) { html_error('Error getting direct link'); }
				
				$Url = parse_url($Href);
				$Referer = $LINK;
				$FileName = !$FileName ? basename($Url["path"]) : $FileName;
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
      	    case "depositfiles.com":
				$temp_url=$Url["path"].($Url["query"] ? "?".$Url["query"] : "");
				$temp_url=($temp_url[3] != "/") ? "/en".$temp_url : $temp_url;
				$page = geturl($Url["host"], 80, $temp_url, 0, 0, 0, 0, $_GET["proxy"],$pauth);
      	       
				is_page($page);
      	        
				is_present($page,"No such file, or file inaccessible for downloading");
				is_present($page,"From yours IP addresses already there is a downloading a file from our system");
      	       
				$countDown=trim(cut_str($page,"show_url(",");"));
				insert_timer($countDown, "File is being prepared.","",true);
               
				$Href = cut_str($page, "var dwnsrc = \"", "\";");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
      	    break;
      	    
      	    case "filefactory.com":
      	    case "www.filefactory.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page, 'Sorry, this file is no longer available');
				is_present($page, 'Sorry, there are currently no free download slots available on this server');
				
				$Referer = $LINK;
				
				$Href = "http://www.filefactory.com/dlf".cut_str($page, '<a href="/dlf', '">');
				$Url = parse_url($Href);
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Referer = $Href;
				$Href = "http://dl".cut_str($page, '<a href="http://dl', '">');
								
				$Url = parse_url($Href);
				$FileName = "attachment";

				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
      	    case "rapidshare.de":
				if (($_GET["rs_acc"] == "on" && $_GET["rs_user"] && $_GET["rs_pass"]) || ($_GET["rs_acc"] == "on" && $rs["de"]["user"] && $rs["de"]["pass"]))
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page,"File not found");
					is_present($page,"This file has been deleted");
					is_present($page,"Inactivity-timeout exceeded");
					is_present($page,"unavailable due to technical-maintenance", "Download-Server unavailable due to maintenance");
					is_present($page,"unavailable due to hardware-problems", "Server unavailable due to hardware-problems");
					
					$FileName = basename(trim(cut_str($page, 'name="uri" value="', '"')));
					!$FileName ? $FileName = basename($Url["path"]) : "";
					$auth = $_GET["rs_user"] ? base64_encode($_GET["rs_user"].":".$_GET["rs_pass"]) : base64_encode($rs["de"]["user"].":".$rs["de"]["pass"]);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth, $auth);
					is_page($page);
					
					if (stristr($page,"Location:"))
						{
						$Href = trim(cut_str($page,"Location:","\n"));
						$Url = parse_url($Href);
		               	
		               	insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "")."&auth=".$auth.($pauth ? "&pauth=$pauth" : ""));
						exit;
						}
					else
						{
						html_error("Cannot use premium account");
						}
					}
				else
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					is_present($page,"File not found");
					is_present($page,"This file has been deleted");
					is_present($page,"Inactivity-timeout exceeded");
					is_present($page,"unavailable due to technical-maintenance", "Download-Server unavailable due to maintenance");
					is_present($page,"unavailable due to hardware-problems", "Server unavailable due to hardware-problems");
					
					$post = array();
					$post["uri"] = $Url["path"];
					$post["dl.start"] = "Free";
					
					$Href = trim(cut_str($page, '<form action="', '"'));
					$Url = parse_url($Href);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : "") ,$LINK , 0, $post, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page, "is not allowed to use the free-service anymore today","No More Free Downloads from this IP today");
					is_present($page, "This file exceeds your download-limit","Excess of the quota");
					is_present($page, "KB in one hour","Excess of the quota");
					is_present($page, "is already downloading a file","Your IP-address is already downloading a file");
					
					if (stristr($page, "Want to download more?"))
						{
						$minutes = trim(cut_str($page, "Or wait", "minute"));
						if ($minutes)
							{
							html_error("Service speaks that it is necessary to wait ".$minutes." minutes");
							}
						else
							{
							html_error("Service speaks that you've reached your download quota on this IP-address.");
							}
						}

					if(stristr($page, "Too many users downloading right now") || stristr($page, "Too many connections"))
						{
						html_error("Service indicates that too many users are connected<br><span id=\"repeat\"></span>\n<script>\nvar c = 10;\nfc();\nfunction fc() {\nif(c > 0)\n{\ndocument.getElementById(\"repeat\").innerHTML = \"Retry in \" + c + ' seconds.';\nc = c - 1;\nsetTimeout(\"fc()\", 1000)\n}\nelse\n{\nlocation.reload();\n}\n}\n</script>\n");
						}
					
					$countDown = trim(cut_str($page, "var c =", ";"));
					
					$code = urldecode(cut_str($page, "unescape('", "'"));
					
					if (!$code)
						{
						html_error('Error getting access code');
						}
					
					$access_image_url = trim(cut_str($code,'<img src="','">'));
					
					if (!$access_image_url)
						{
						html_error('Error getting access image url');
						}
					
					if ($images_via_php === true)
						{
						$code = str_replace($access_image_url, $PHP_SELF."?image=".urlencode(trim(cut_str($code, '<img src="', '">')))."&referer=".urlencode($Url["scheme"]."://".$Url["host"]."/"), $code);
						}
					
					$newcap = false;
					
					$FileAddr = trim(cut_str($code, '<form name="dl" action="', '"'));
					$FileName = basename($FileAddr);
				
					if (!$FileAddr)
						{
						echo '<b>Something wrong in this code... </b>';
						echo $Href;
						}
					if(!$Href)
						{
						html_error("Error getting download link");
						}
					
					$capthatag = cut_str($code,'here: <input','>');
					$capthatag = cut_str($capthatag,'name="','"');
					
					preg_match_all("/http:\/\/dl(.*).rapidshare.de\/(.*)".$FileName."/iU", $code, $matches);
					
					if (!$matches)
						{
						html_error("Error getting available server's list");
						}
					
					for ($i = 0; $i < count($matches[0]); $i++)
						{
						$link = "redir.php?capthatag=".$capthatag."&saveto=".$_GET["saveto"]."&path=".$_GET["path"]."&comment=".$_GET["comment"]."&domail=".$_GET["domail"]."&email=".$_GET["email"]."&useproxy=".$_GET["useproxy"]."&proxy=".$_GET["proxy"]."&split=".$_GET["split"]."&method=".$_GET["method"]."&partSize=".$_GET["partSize"]."&redirto=".$PHP_SELF."&link=".$matches[0][$i].($pauth ? "&pauth=$pauth" : "");
						$code = str_replace($matches[0][$i], $link, $code);
						}
					
					if ($newcap === false)
						{
						insert_new_timer($countDown, rawurlencode($code), "Download-Ticket reserved.");
						}
					else
						{
						$Href = "$FileAddr?".$capthatag."=$newcap";
						
						$Referer = $Url["scheme"]."://".$Url["host"]."/";
						$Url = parse_url($Href);
						
						insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
						}
					exit;
					}
      	    break;
      	    case "rapidshare.com":
      	    	if (($_GET["rs_acc"] == "on" && $_GET["rs_user"] && $_GET["rs_pass"]) || ($_GET["rs_acc"] == "on" && $rs["com"]["user"] && $rs["com"]["pass"]))
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page,"File not found");
					is_present($page,"This file has been deleted");
					is_present($page,"Inactivity-timeout exceeded");
					is_present($page,"unavailable due to technical-maintenance", "Download-Server unavailable due to maintenance");
					is_present($page,"unavailable due to hardware-problems", "Server unavailable due to hardware-problems");
					
					$FileName = basename(trim(cut_str($page, '<form action="', '"')));
					!$FileName ? $FileName = basename($Url["path"]) : "";
					$auth = $_GET["rs_user"] ? base64_encode($_GET["rs_user"].":".$_GET["rs_pass"]) : base64_encode($rs["com"]["user"].":".$rs["com"]["pass"]);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth, $auth);
					is_page($page);
					
					if (stristr($page,"Location:"))
						{
						$Href = trim(cut_str($page,"Location:","\n"));
						$Url = parse_url($Href);
		               	
		               	insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "")."&auth=".$auth.($pauth ? "&pauth=$pauth" : ""));
						exit;
						}
					else
						{
						html_error("Cannot use premium account");
						}
					}
				else
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					is_present($page,"File not found");
					is_present($page,"This file has been deleted");
					is_present($page,"Inactivity-timeout exceeded");
					is_present($page,"unavailable due to technical-maintenance", "Download-Server unavailable due to maintenance");
					is_present($page,"unavailable due to hardware-problems", "Server unavailable due to hardware-problems");
					
					$post = array();
					$post["dl.start"] = "Free";
					
					$Href = trim(cut_str($page, '<form action="', '"'));
					$Url = parse_url($Href);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : "") ,$LINK , 0, $post, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page, "is not allowed to use the free-service anymore today","No More Free Downloads from this IP today");
					is_present($page, "This file exceeds your download-limit","Excess of the quota");
					is_present($page, "KB in one hour","Excess of the quota");
					is_present($page, "is already downloading a file","Your IP-address is already downloading a file");
					
					if (stristr($page, "Want to download more?"))
						{
						$minutes = trim(cut_str($page, "Or wait", "minute"));
						if ($minutes)
							{
							html_error("Service speaks that it is necessary to wait ".$minutes." minutes");
							}
						else
							{
							html_error("Service speaks that you've reached your download quota on this IP-address.");
							}
						}
				

					if(stristr($page, "Too many users downloading right now") || stristr($page, "Too many connections"))
						{
						html_error("Service indicates that too many users are connected<br><span id=\"repeat\"></span>\n<script>\nvar c = 10;\nfc();\nfunction fc() {\nif(c > 0)\n{\ndocument.getElementById(\"repeat\").innerHTML = \"Retry in \" + c + ' seconds.';\nc = c - 1;\nsetTimeout(\"fc()\", 1000)\n}\nelse\n{\nlocation.reload();\n}\n}\n</script>\n");
						}
					
					$countDown = trim(cut_str($page, "var c=", ";"));
					
					if (!$countDown)
						{
						$code = '<form name="dl" '.trim(cut_str($page, '<form name="dl" ', '</form>')).'</form>';
						}
					else
						{
						$code = urldecode(cut_str($page, "unescape('", "'"));
						}
					
					if (!$code)
						{
						html_error('Error getting access code');
						}
					
					$access_image_url = trim(cut_str($code,'<img src="','">'));
					
					if (!$access_image_url)
						{
						html_error('Error getting access image url');
						}
					
					if ($images_via_php === true)
						{
						$code = str_replace($access_image_url, $PHP_SELF."?image=".urlencode(trim(cut_str($code, '<img src="', '">')))."&referer=".urlencode($Url["scheme"]."://".$Url["host"]."/"), $code);
						}
					
					$newcap = false;
					
					$FileAddr = trim(cut_str($code, '<form name="dl" action="', '"'));
					$FileName = basename($FileAddr);
				
					if (!$FileAddr)
						{
						echo '<b>Something wrong in this code... </b>';
						echo $Href;
						}
					if(!$Href)
						{
						html_error("Error getting download link");
						}
					
					$capthatag = cut_str($code,'<input type="text"','>');
					$capthatag = cut_str($capthatag,'name="','"');
					
					preg_match_all("/http:\/\/rs(.*).rapidshare.com\/(.*)".$FileName."/iU", $code, $matches);
					
					if (!$matches)
						{
						html_error("Error getting available server's list");
						}
					
					for ($i = 0; $i < count($matches[0]); $i++)
						{
						$link = "redir.php?capthatag=".$capthatag."&saveto=".$_GET["saveto"]."&path=".$_GET["path"]."&comment=".$_GET["comment"]."&domail=".$_GET["domail"]."&email=".$_GET["email"]."&useproxy=".$_GET["useproxy"]."&proxy=".$_GET["proxy"]."&split=".$_GET["split"]."&method=".$_GET["method"]."&partSize=".$_GET["partSize"]."&redirto=".$PHP_SELF."&link=".$matches[0][$i].($pauth ? "&pauth=$pauth" : "");
						$code = str_replace($matches[0][$i], $link, $code);
						}
					
					if (!$countDown)
						{
						print $code.'</body></html>';
						}
					else
						{
						insert_new_timer($countDown, rawurlencode($code), "Download-Ticket reserved.");
						}
					exit;
					}
      	    break;
      	    
      	    case "www.megarotic.com":
				if ($_GET["step"] == "1")
					{
					$post["d"] = $_GET["fileid"];
					$post["imagecode"] = $_GET["imagecode"];
					$post["imagestring"] = $_GET["imagestring"];
					$post["megavar"] = $_GET["megavar"];
					
					$Href = $LINK;
					$url = parse_url($Href);
					
					$page = geturl($url["host"], $url["port"] ? $url["port"] : 80, $url["path"].($url["query"] ? "?".$url["query"] : ""), $Referer, 0, $post, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page,"The file you are trying to access is temporarily unavailable");
					
					$findvar = cut_str($page, "'Please wait '+","+' seconds");
					$countDown = trim(cut_str($page, $findvar."=", ";"));
					$countDown = $countDown ? $countDown : 46;
					
					$tmp = cut_str($page, 'if('.$findvar.' == 0)', 'if('.$findvar.' > 0)');
					$Href = cut_str($tmp, 'document.getElementById("downloadhtml").innerHTML = \'<a href="', '"');
					$Url = parse_url($Href);
					$FileName = !$FileName ? basename($Url["path"]) : $FileName;
					
					if (!$Url)
						{
						html_error("Error getting download link");
						}
				
					insert_timer($countDown, "The file is being prepared.","",true);
					
					insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
					}
				else
					{
					list ($tmp,$fid)=explode('=',$Url["query"]);
					$page = geturl($Url["host"], 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page, 'The file you are trying to access is temporarily unavailable');
					is_present($page, 'the link you have clicked is not available', 'Invalid link');
					is_present($page, 'This file has expired due to inactivity');
					
					$Href = cut_str(cut_str($page, '<div id="downloadbutton"', '</div>'), '<form method="POST" action="', '"');
					$Referer = $LINK;
			
					if (stristr($page,"All download slots") && stristr($page,"assigned to your country"))  
						{
						html_error("All download slots assigned to your country are in use. Please try again later.");
						}

					is_notpresent($page,'capgen.php','Service changed protection method');
					if (stristr($page,'/capgen.php?'))
						{
						$imagecode = cut_str($page,'<input type="hidden" name="imagecode" value="','"');
						$capcode = cut_str($page,'capgen.php?','"');
						$megavar = cut_str($page, '<input type="hidden" name="megavar" value="', '">');
					
						$access_image_url = $Url["scheme"]."://".$Url["host"]."/capgen.php?".$capcode;
						
						print "<form action=\"$PHP_SELF\" method=\"post\">\n";
						print "<input type=\"hidden\" name=\"link\" value=\"".urlencode($Href)."\">\n<input type=\"hidden\" name=\"referer\" value=\"".urlencode($Referer)."\">\n<input type=\"hidden\" name=\"fileid\" value=\"$fid\">\n<input type=\"hidden\" name=\"imagecode\" value=\"$imagecode\">\n<input type=\"hidden\" name=\"megavar\" value=\"$megavar\">\n<input type=\"hidden\" name=\"step\" value=\"1\">\n";
						print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\n";
						print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\n";
						print "<h4>Enter <img src=\"$access_image_url\"> here: <input type=\"text\" name=\"imagestring\" size=\"3\" maxlength=\"3\">  <input type=\"submit\" value=\"Download File\"></h4>\n";
						print "</form>\n</body>\n</html>";
						flush();
						}
					}
				exit;
      	    break;
      	    
      		case "www.megaupload.com":
				if ($_GET["step"] == "1")
					{
					$post["d"] = $_GET["fileid"];
					$post["imagecode"] = $_GET["imagecode"];
					$post["imagestring"] = $_GET["imagestring"];
					$post["megavar"] = $_GET["megavar"];
					
					$Href = $LINK;
					$Url = parse_url($Href);
					
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, $post, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page,"The file you are trying to access is temporarily unavailable");
					
					$findvar = cut_str($page, "'Please wait '+","+' seconds");
					$countDown = trim(cut_str($page, $findvar."=", ";"));
					$countDown = $countDown ? $countDown : 46;
					
					$tmp = cut_str($page, 'if('.$findvar.' == 0)', 'if('.$findvar.' > 0)');
					$tmp_url = cut_str($tmp, "document.getElementById(\"downloadhtml\").innerHTML = '<a href=\"", "\" class=\"downloadlink\"");
					$Url = parse_url($tmp_url);
					
					if (!$Url)
						{
						html_error("Error getting download link");
						}
					
					$Href = cut_str($tmp, "+ String.fromCharCode", "' +");
					$Href = cut_str($Href, "document.getElementById(\"download_html\").innerHTML = '<a href=\"", "/files/");
					$Href.= $Url["path"];
					
					if (!$Href)
						{
						html_error("Error getting download link");
						}
					
					insert_timer($countDown, "The file is being prepared.","",true);
					
					$Url = parse_url($Href);
					$FileName = ! $FileName ? basename($Url["path"]) : $FileName;
					
					insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
					}
				else
					{
					list ($tmp,$fid)=explode('=',$Url["query"]);
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					is_present($page, 'The file you are trying to access is temporarily unavailable');
					is_present($page, 'the link you have clicked is not available', 'Invalid link');
					is_present($page, 'This file has expired due to inactivity');
					
					$Href = cut_str(cut_str($page, '<div id="downloadbutton"', '</div>'), '<form method="POST" action="', '"');
					$Referer = $LINK;
			
					if (stristr($page,"All download slots") && stristr($page,"assigned to your country"))  
						{
						html_error("All download slots assigned to your country are in use. Please try again later.");
						}

					is_notpresent($page,'capgen.php','Service changed protection method');
					if (stristr($page,'/capgen.php?'))
						{
						$imagecode = cut_str($page,'<input type="hidden" name="imagecode" value="','"');
						$capcode = cut_str($page,'capgen.php?','"');
						$megavar = cut_str($page, '<input type="hidden" name="megavar" value="', '">');
					
						$access_image_url = $Url["scheme"]."://".$Url["host"]."/capgen.php?".$capcode;
						
						print "<form action=\"$PHP_SELF\" method=\"post\">\n";
						print "<input type=\"hidden\" name=\"link\" value=\"".urlencode($Href)."\">\n<input type=\"hidden\" name=\"referer\" value=\"".urlencode($Referer)."\">\n<input type=\"hidden\" name=\"fileid\" value=\"$fid\">\n<input type=\"hidden\" name=\"imagecode\" value=\"$imagecode\">\n<input type=\"hidden\" name=\"megavar\" value=\"$megavar\">\n<input type=\"hidden\" name=\"step\" value=\"1\">\n";
						print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\n";
						print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\n";
						print "<h4>Enter <img src=\"$access_image_url\"> here: <input type=\"text\" name=\"imagestring\" size=\"3\" maxlength=\"3\">  <input type=\"submit\" value=\"Download File\"></h4>\n";
						print "</form>\n</body>\n</html>";
						flush();
						}
					}
				exit;
      		break;

			case "www.sexuploader.com":
				do
					{
						$page = geturl($Url["host"], 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
						$location=trim(cut_str($page,"Location:","\n"));
						if ($location)
							{
								$Url=parse_url($location);
							}
					}
				while ($location);
				
				is_page($page);
				
				$Referer="http://".$Url["host"].$Url["path"].($Url["query"] ? "?".$Url["query"] : "");
				
				if (stristr($page,"All download slots") && stristr($page,"assigned to your country"))  
					{
						html_error("All download slots assigned to your country are in use");
					}

				is_present($page,"The file you are trying to access is temporarily unavailable");
				
				$findvar = cut_str($page, "'Please wait '+","+' seconds");
				$countDownLeft = $findvar . "=";
				$countDown = trim(cut_str($page, $countDownLeft, ";"));
				$countDown = $countDown ? $countDown : 50;
				
				if (eregi("' \+ [a-z] \+ [a-z] \+ [a-z] \+ '",$page))
					{
						ereg("' \+ [a-z] \+ [a-z] \+ [a-z] \+ '",$page,$reg);
						$str_func=$reg[0];
						ereg("[a-z] \+ [a-z] \+ [a-z]",$page,$reg);
						$str_func_2=$reg[0];
						
					}
						else
					{
						html_error('Error decoding html code');
					}
				
				insert_timer($countDown, "File is being prepared.","",true);

				$out=explode('+',$str_func_2);
				
				$new_val="";
				
				for ($y=0; $y<count($out); $y++)
					{
						$var_=trim($out[$y]);
						$val_=cut_str($page,"var $var_ = ",";");
						
						if (strstr($val_,"String.fromCharCode("))
							{
								if (strstr($val_,"String.fromCharCode(Math.sqrt("))
									{
										$val_temp=cut_str($val_,"String.fromCharCode(Math.sqrt(",")");
										$val_=chr(sqrt($val_temp));
									}
										else
									{
										$val_temp=cut_str($val_,"String.fromCharCode(",")");
										$val_=chr($val_temp);
									}
							}
								else
							{
								$val_=str_replace("'", "", $val_);
							}
						$new_val.=$val_;
					}
				
				
				$var_tmp=cut_str($page,"String.fromCharCode(","class=");
				$Href=cut_str($var_tmp,'href="','"');
				$Href=str_replace($str_func, $new_val,$Href);

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;

			case "slil.ru":
			case "zalil.ru":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"] ,$pauth);
				is_page($page);
				
				$Href = "http://".$Url["host"].cut_str($page, ";URL=", "\"");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;

			case "webfile.ru":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Href = "http://webfile.ru".cut_str($page, "<p class=link><b>&gt;&gt;&gt <a href=\"", "\"");
				$Tmp = parse_url($Href);
				$Referer = $Href;
				
				$page=geturl($Tmp["host"], 80, $Tmp["path"], $Href, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Href = cut_str($page, "Location: ", "\r");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;

			case "getfile.biz":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);

            	$Href = cut_str($page, "</b><br><br>\n<a href=\"", "\"");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "ultrashare.net":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				is_notpresent($page,"The following file is available for download");
				
				$FileName=cut_str($page,"File name: <b>","</b>");
				$Href="http://ultrashare.net/hosting/sf/".cut_str($page,"<a href=\"http://ultrashare.net/hosting/dl/","\">Click here to download");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "sr1.mytempdir.com":
			case "www.mytempdir.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
					
					
				is_present($page,"is already downloading a file, you can't download more than one file at a time.","Is already downloading a file from this IP");
				
				$countDown = cut_str($page, "loading()', ", "000);");
				insert_timer($countDown, "File is being prepared.","",true);
				
				$Href = cut_str(urldecode(cut_str($page, "scape('", "')")), "Download: <a href=\"", "\"");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.speedshare.org":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Referer = $LINK;
				$Href = trim(cut_str($page, '<form action="', '"'));
				$Url = parse_url($Href);
				$Post = array();
				$Post["a"] = "show2";
				$Post["datei"] = trim(cut_str($page, 'name="datei" value="', '"'));
				$Post["downloadpasswort"] = "test";
				$Post["dl"] = "Download";
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, $Post, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Referer = $Href;
				$Href = trim(cut_str($page,"Location:","\n"));
				$Url = parse_url($Href);
				$FileName = "attachment";
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&port=".$Url[port]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "files.to":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page,"File does not exist","File doesn't exist");
				
				//$countDown = cut_str($page, "var timer=", ";");
				//insert_timer($countDown, "File is being prepared.","",true);
				
				$Href = cut_str($page, "<form action=\"", "\" method=\"post\">");
				
				$Url = parse_url($Href);
				$tmp = $tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
				$post = array();
				$post["x"] = 99;
				$post["y"] = 333;
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&port=".$Url[port]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&post=".urlencode(serialize($post))."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "d.turboupload.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
			
				$countDown = cut_str($page, "var t = ", "; tuw();");
				insert_timer($countDown, "File is being prepared.","",true);

				$Href = urldecode(cut_str($page, "scape('", "');\nsetTimeout(\"tuw()\""));

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;

			case "up-file.com":
			case "www.up-file.com":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				is_present($page,"File deleted for abuse","This file deleted from servers");
				
				$noSecondPage = FALSE;
				
            
				$countDown = cut_str($page, "x7157=", ";\nfunction");
				insert_timer($countDown, "File is being prepared.","",true);
            
				$url=cut_str($page,"<a href=\"/download2/",".html\"");
				if (!$url)
					{
						html_error("File not found or deleted");
					}
            	
				$url="/download2/".$url.".html";
				$Referer = "http://".$Url[host].$url;
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $url, 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$u=cut_str($page,"var u='","';");
				$z=cut_str($page,"var z='","';");
				$s=cut_str($page,"var s='","';");
				$f=cut_str($page,"var f='","';");
				$Href = "http://".$s.".up-file.com/download3/".$u."_".$z."/".$f;

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "www.upload2.net":
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, 0, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$countDown = cut_str($page, "wt=", ";func");
				insert_timer($countDown, "File is being prepared.","",true);

            	$Href = cut_str($page, "document.getElementById(\"dl\").innerHTML='<a class=common href=\"", "\">Click here to");

				$Url = parse_url($Href);
				$tmp = explode("/", $Href);
				$FileName = !$FileName ? basename(array_pop($tmp)) : $FileName;
               
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($_GET["link"]).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "storeandserve.com":
				$Cookie = "cokEmail=kloon%40altavizsla.hu; expires=Sun, 23 Sep 2007 09:08:07 GMT; path=/; domain=storeandserve.com";
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), 0, $Cookie, 0, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				unset($post);
				$post["id"] = trim(cut_str($page, "<input type='hidden' name='id' value='", "'>"));
				$post["flnamedh"] = trim(cut_str($page, "<input type='hidden' name='flnamedh' value='", "'>"));
				$post["btnDownloadFree"] = "Download!";
				
				$Href = "http://".$Url["host"]."/?downloads/download_page2";
				$Url = parse_url($Href);
				
				$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, $Cookie, $post, 0, $_GET["proxy"],$pauth);
				is_page($page);
				
				$Href = trim(cut_str($page, "<b><a href=", ">"));
				
				if (!$Href)
					{
					html_error("Error getting download link");
					}
				
				$Url = parse_url($Href);
				$FileName = basename($Url["path"]);
				
				insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path].($Url["query"] ? "?".$Url["query"] : ""))."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").($pauth ? "&pauth=$pauth" : ""));
				exit;
			break;
			
			case "uploadport.com":
			case "www.uploadport.com":
				if ($_GET["step"] == "1")
					{
					$rid = $_REQUEST["rid"];
					$Href = $LINK;
					$Url = parse_url($Href);
					$Referer = urldecode($_REQUEST["referer"]);
					$Cookie = unserialize(urldecode($_REQUEST["cookie"]));

					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), ($Referer ? $Referer : 0), $Cookie, 0, 0, $_GET["proxy"],$pauth);		
					is_page($page);
					print $page;
					exit;
					$Referer = $Href;
					$Href = trim(cut_str($page,'--><a href="','" style="'));
					
					if (!$Href)
						{
						html_error("Error getting download link");
						}
					
					$Url = parse_url($Href);
					$FileName = basename($Url["path"]);
					
					$auth=($Url["user"] & $Url["pass"]) ? $auth = "&auth=".base64_encode($Url["user"].":".$Url["pass"]) : "";
					insert_location("$PHP_SELF?FileName=".urlencode($FileName)."&host=".$Url[host]."&path=".urlencode($Url[path])."&referer=".urlencode($Referer)."&email=".($_GET["domail"] ? $_GET["email"] : "")."&partSize=".($_GET[split] ? $_GET[partSize] : "")."&method=".$_GET[method]."&proxy=".($_GET["useproxy"] ? $_GET["proxy"] : "")."&saveto=".$_GET["path"]."&link=".urlencode($Href).($_GET["add_comment"] == "on" ? "&comment=".urlencode($_GET["comment"]) : "").$auth.($pauth ? "&pauth=$pauth" : ""));
					}
				else
					{
					$page = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), ($Referer ? $Referer : 0), $Cookie, 0, 0, $_GET["proxy"],$pauth);
					is_page($page);
					
					$Cookie = urlencode(serialize(GetCookies($page)));
					
					$countDown = 15;
					insert_timer($countDown, "Getting ticket.","",true);
					
					$rid = trim(cut_str($page,'<img src="http://www.uploadport.com/turing-getimg/?rid=','" border="0">')) or trim(cut_str($page,'<img src="http://uploadport.com/turing-getimg/?rid=','" border="0">'));
					$access_image_url = "http://www.uploadport.com/turing-getimg/?rid=".$rid;
					$Href = "http://www.uploadport.com/download/?rid=".$rid;
					$Referer = $LINK;

					if (!$access_image_url)
						{
						html_error('Error getting access image url');
						}
					
					print "<form action=\"$PHP_SELF\" method=\"post\" onsubmit=\"turingAuth();\">\n<h4>Enter <img src=\"$access_image_url\"> here:<input type=\"text\" name=\"turing\" id=\"turing\" size=\"5\" maxlength=\"6\">\n<input type=\"submit\" value=\"Download File\"></h4>\n";
					print "<input type=\"hidden\" name=\"link\" id=\"link\" value=\"".urlencode($Href)."\">\n<input type=\"hidden\" name=\"referer\" id=\"referer\" value=\"".urlencode($Referer)."\">\n<input type=\"hidden\" name=\"rid\" id=\"rid\" value=\"$rid\">\n<input type=\"hidden\" name=\"step\" id=\"step\" value=\"1\">\n<input type=\"hidden\" name=\"cookie\" id=\"cookie\" value=\"$Cookie\">\n";
					print "<input type=\"hidden\" name=\"comment\" id=\"comment\" value=\"".$_GET["comment"]."\">\n<input type=\"hidden\" name=\"email\" id=\"email\" value=\"".$_GET["email"]."\">\n<input type=\"hidden\" name=\"partSize\" id=\"partSize\" value=\"".$_GET["partSize"]."\">\n<input type=\"hidden\" name=\"method\" id=\"method\" value=\"".$_GET["method"]."\">\n";
					print "<input type=\"hidden\" name=\"proxy\" id=\"proxy\" value=\"".$_GET["proxy"]."\">\n<input type=\"hidden\" name=\"proxyuser\" id=\"proxyuser\" value=\"".$_GET["proxyuser"]."\">\n<input type=\"hidden\" name=\"proxypass\" id=\"proxypass\" value=\"".$_GET["proxypass"]."\">\n<input type=\"hidden\" name=\"path\" id=\"path\" value=\"".$_GET["path"]."\">\n";
					print "<script language=\"JavaScript\">\nvar req;\nfunction turingAuth() {\nturing=document.getElementById('turing').value;\nrid=document.getElementById('rid').value;\nloadXMLDoc('http://www.uploadport.com/turing-authorize/?rid='+rid+'&turing='+turing);\nreturncode = req.responseText;\nif (returncode == \"1\") {\nreturn true;\n} else {\nreturn false;\nwindow.location.reload();\n}\n}\n";
					print "function loadXMLDoc(url) {\nreq = false;\nif(window.XMLHttpRequest) {\ntry {\nreq = new XMLHttpRequest();\n} catch(e) {\nreq = false;\n}\n} else if(window.ActiveXObject) {\ntry {\nreq = new ActiveXObject(\"Msxml2.XMLHTTP\");\n} catch(e) {\ntry {\nreq = new ActiveXObject(\"Microsoft.XMLHTTP\");\n";
					print "} catch(e) {\nreq = false;\n}\n}\n}\n\nif(req) {\nreq.open(\"GET\", url, false);\nreq.send(\"\");\n}\n}\n</script>\n</form>\n</body>\n</html>";
					flush();
					}
				exit;
      	    break;
			
      	    default:
      	       html_error("This service is not supported");
      	    break;
          }
      }

?>