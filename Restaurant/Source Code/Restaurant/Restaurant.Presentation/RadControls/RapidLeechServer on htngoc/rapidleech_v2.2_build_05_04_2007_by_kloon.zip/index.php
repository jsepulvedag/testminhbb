<?php
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit", "1024M");
ob_end_clean();
ob_implicit_flush(TRUE);
ignore_user_abort(1);
error_reporting(7);

$nn = "\r\n";
$fromaddr = "RapidLeech";
$PHP_SELF = !$PHP_SELF ? $_SERVER["PHP_SELF"] : $PHP_SELF;
$systemfile = array("sendspace.php","config.php","cookie.php","function.php","notlink.php","redir.php","files.lst","resume.lst","Tar.php","PEAR.php","pclzip.php","host.php","currently_works_with.gif","dots_vert.gif","links.gif","logo.gif","main_window.gif","server_files.gif","settings.gif");
$systemfile[]= basename(trim($PHP_SELF));

define('RAPIDLEECH','yes');
define('VERSION', "RapidLeech V2.2<br>Credits to Pramode & Checkmate<br>Build 05.04.2007 by Kloon");

require_once "config.php";

if ($no_cache)
 {
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache");
 }

if(!defined('CRLF')) define('CRLF',"\r\n");
if(!defined("FTP_AUTOASCII")) define("FTP_AUTOASCII", -1);
if(!defined("FTP_BINARY")) define("FTP_BINARY", 1);
if(!defined("FTP_ASCII")) define("FTP_ASCII", 0);
if(!defined('FTP_FORCE')) define('FTP_FORCE', TRUE);
define('FTP_OS_Unix','u');
define('FTP_OS_Windows','w');
define('FTP_OS_Mac','m');

require_once "function.php";

register_shutdown_function("pause_download");

if (is_file($users_file) && is_readable($users_file))
	{
	require_once($users_file);
	}

if ($login === true && (!isset($_SERVER['PHP_AUTH_USER']) || ($loggeduser = logged_user($users)) === false))
	{
		header("WWW-Authenticate: Basic realm=\"RapidLeech\"");
		header("HTTP/1.0 401 Unauthorized");
		exit("<html>$nn<head>$nn<title>RAPIDLEECH V2.2</title>$nn<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">$nn</head>$nn<body>$nn<h1><a href=http://www.rapidleech.com>RapidLeech</a>: Access Denied - Wrong Username or Password</h1>$nn</body>$nn</html>");
	}

define('PATH_SPLITTER', (strstr(realpath("./"), ":") ? "\\" : "/"));

foreach($_POST as $key => $value)
  {
  $_GET[$key] = $value;
  }

if(!$_COOKIE)
  {
      if(strstr($_SERVER["HTTP_COOKIE"], ";"))
        {
            foreach(explode("; ", $_SERVER["HTTP_COOKIE"]) as $key => $value)
              {
                  list($var, $val) = explode("=", $value);
                  $_COOKIE[$var] = $val;
              }
        }
      else
        {
          list($var, $val) = @explode("=", $_SERVER["HTTP_COOKIE"]);
          $_COOKIE[$var] = $val;
        }
  }

require_once "cookie.php";

if (!empty($_GET["image"]))
	{
	$LINK = trim(urldecode($_GET["image"]));
	$Url = parse_url($LINK);
	$Referer = ($_GET["referer"] ? trim(urldecode($_GET["referer"])) : $LINK);
	$Image = geturl($Url["host"], $Url["port"] ? $Url["port"] : 80, $Url["path"].($Url["query"] ? "?".$Url["query"] : ""), $Referer, 0, 0, 0, $_GET["proxy"], $pauth, $auth, $Url["scheme"]);
	if ($Image)
		{
		if(stristr($Image, "\n\n"))
			{
            $det = "\n\n";
            }
        elseif(stristr($Image, $nn.$nn))
            {
            $det = $nn.$nn;
            }
        if($det)
            {
            $Image = explode($det, $Image);
            $header = explode("\n", $Image[0]);
            foreach ($header as $value)
				{
				header($value);
				}
			echo $Image[1];
            }
		}
	exit;
	}

if(isset($_GET["useproxy"]) & (!$_GET["proxy"] || !strstr($_GET["proxy"], ":")))
      {
        html_error("Not address of the proxy server is specified");
      }
      	else
      {
      	if ($_GET["pauth"])
      		{
      			$pauth = $_GET["pauth"];
      		}
      			else
      		{
      			$pauth = ($_GET["proxyuser"] && $_GET["proxypass"]) ? base64_encode($_GET["proxyuser"].":".$_GET["proxypass"]) : "";
      		}
      }

if(!$_GET["FileName"] || !$_GET["host"] || !$_GET["path"])
  {
    $LINK = trim(urldecode($_GET["link"]));
    if(!$LINK) { require_once "notlink.php"; die; }
      

    if(isset($_GET["saveto"]) & !$_GET["path"])
      {
        html_error("Path is not specified for saving this file");
      }
      
    if (!isset($_GET["useproxy"]))
    	{
    		$_GET["proxy"] = "";
    	}
    	
    if(isset($_GET["domail"]) & !checkmail($_GET["email"]))
      {
        html_error("Is Not specified or wrong E-mail");
	    if($_GET["split"] & !is_numeric($_GET["partSize"]))
	      {
	        html_error("Untrue a size of the part is specified");
	      }
      }
      
    $Referer = ($_GET["referer"] ? trim(urldecode($_GET["referer"])) : $LINK);
    $Url = parse_url($LINK);
    
    require_once("host.php");
  }
else
  {
    ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title>Downloading...</title>
</head>
<body style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;">
<center>
    <?php
    
    do
    	{
		    list($_GET["FileName"],$tmp) = explode('?',urldecode(trim($_GET["FileName"])));
		    $_GET["saveto"] = urldecode(trim($_GET["saveto"]));
		    $_GET["host"] = urldecode(trim($_GET["host"]));
		    $_GET["path"] = urldecode(trim($_GET["path"]));
		    $_GET["port"] = $_GET["port"] ? urldecode(trim($_GET["port"])) : 80;
		    $_GET["referer"] = $_GET["referer"] ? urldecode(trim($_GET["referer"])) : 0;
		    $_GET["link"] = urldecode(trim($_GET["link"]));
		    $_GET["post"] = $_GET["post"] ? unserialize(stripslashes(urldecode(trim($_GET["post"])))) : 0;
		    $_GET["cookie"] = $_GET["cookie"] ? urldecode(trim($_GET["cookie"])) : 0;
		    $resume_from = $_GET["resume"] ? intval(urldecode(trim($_GET["resume"]))) : 0;
		    if ($_GET["resume"]) {unset($_GET["resume"]);}

			$redirectto = "";
		    //$_GET["path"] = str_replace("act=ftp_get", "act=ftpget", $_GET["path"]);
		    
		    $pauth = urldecode(trim($_GET["pauth"]));
		    $auth = urldecode(trim($_GET["auth"]));

		    if($_GET["auth"])
		      {
		          $AUTH["use"] = TRUE;
		          $AUTH["str"] = $_GET["auth"];
		      }
		    else
		      {
		          unset($AUTH);
		      }

		    //$pathWithName = $_GET["saveto"].(strstr(realpath("./"), ":") ? "\\\\" : "/").$_GET["FileName"];
		    $ftp = parse_url($_GET["link"]);
		    
		    $IS_FTP = $ftp["scheme"] == "ftp" ? TRUE : FALSE;
		    $AUTH["ftp"] = array("login"    => $ftp["user"] ? $ftp["user"] : "anonymous",
		                         "password" => $ftp["pass"] ? $ftp["pass"] : "anonymous");
		                         
		    $pathWithName = $_GET["saveto"].PATH_SPLITTER.$_GET["FileName"];
		    while(stristr($pathWithName, "\\\\"))
				{
				$pathWithName = str_replace("\\\\", "\\", $pathWithName);				
				}

		    list($pathWithName,$tmp) = explode('?',$pathWithName);

		    if ($ftp["scheme"] == "ftp" && !$_GET["proxy"])
		    	{
		    		$file = getftpurl($_GET["host"], $ftp["port"] ? $ftp["port"] : 21, $_GET["path"], &$pathWithName);
		    	}
		    else
		    	{
		    		$file = geturl($_GET["host"], ($ftp["scheme"] == "ftp") ? ($ftp["port"] ? $ftp["port"] : 21) : ($ftp["port"] ? $ftp["port"] : $_GET["port"]), $_GET["path"], $_GET["referer"], $_GET["cookie"], $_GET["post"], &$pathWithName, $_GET["proxy"], $pauth, $auth, $ftp["scheme"], $resume_from);
		    	}
			
			if($redir && $lastError && stristr($lastError,"Error! it is redirected to ["))
				{
					$redirectto = trim(cut_str($lastError,"Error! it is redirected to [","]"));
					echo "Redirecting to: <b>$redirectto</b> ... <br>";
					$_GET["link"] = $redirectto;
					$purl = parse_url($redirectto);
				    list($_GET["FileName"],$tmp) = explode('?',basename($redirectto));
    				$_GET["path"] = $purl["path"];
    				$lastError = "";
				}
		    
		} while ($redirectto && !$lastError);
	
	//$pathWithName = dirname($pathWithName).PATH_SPLITTER.basename($file["file"]);
	if($lastError)
      {
        html_error($lastError, 0);
      }
    elseif($file["bytesReceived"] == $file["bytesTotal"] || $file["size"] == "Unknown")
      {
        $inCurrDir = stristr(dirname($pathWithName), realpath("./")) ? TRUE : FALSE;
        if($inCurrDir)
          {
            $Path = parse_url($PHP_SELF);
            $Path = substr($Path["path"], 0, strlen($Path["path"]) - strlen(strrchr($Path["path"], "/")));
          }
        echo "<script>pr(100, '".$file["size"]."', '".$file["speed"]."')</script>\r\n";
        echo "File <b>".($inCurrDir ? "<a href=\"".$Path.substr(dirname($pathWithName), strlen(realpath("./")) + 1)."/".basename($file["file"])."\">" : "").basename($file["file"]).($inCurrDir ? "</a>" : "")."</b> (<b>".$file["size"]."</b>) Saved!<br>Time: <b>".$file["time"]."</b><br>Average Speed: <b>".$file["speed"]." KB/s</b><br>";
        if(!write_file("files.lst", serialize(array("name" => $file["file"], "size" => $file["size"], "date" => time(), "link" => $_GET["link"], "comment" => str_replace("\n", "\\n", str_replace("\r", "\\r", $_GET["comment"]))))."\r\n", 0))
          {
            echo "Couldn't update the files list<br>";
          }
        if($_GET["email"])
          {
            $_GET["partSize"] = (isset($_GET["partSize"]) ? $_GET["partSize"] * 1024 * 1024 : FALSE);
            if(xmail($fromaddr, $_GET["email"], "File ".basename($file["file"]), "File: ".basename($file["file"])."\r\n"."Link: ".$_GET["link"].($_GET["comment"]? "\r\n"."Comments: ".str_replace("\\r\\n", "\r\n", $_GET["comment"]) : ""), $pathWithName, $_GET["partSize"], $_GET["method"]))
              {
                echo "<script>mail('File was sent to this address<b>".$_GET["email"]."</b>!', '".basename($file["file"])."');</script>\r\n";
              }
            else
              {
                echo "Error Sending File!<br>";
              }
          }
        $Path = parse_url($PHP_SELF);
        $Path = substr($Path["path"], 0, strlen($Path["path"]) - strlen(strrchr($Path["path"], "?")));
        echo "<br><a href=\"".$Path."\" style=\"color: #0000FF;\">Go Back to Main!</a>";
      }
    else
      {
        echo "Connection Lost :-(<br><a href=\"javascript:location.reload();\">Reload</a>";
      }
    ?>
</center>
</body>
</html>
    <?php
  }
?>