<?php if (!defined('RAPIDLEECH')) {die("not load primary script");} ?>
<!DOCTYPE html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<style type="text/css">
 <!--
  body      {font-family: Tahoma; font-size: 11px;}
  tr        {font-family: Tahoma; font-size: 11px; line-height: 14.5px;}
  input     {font-family: Tahoma; font-size: 11px;}
  select    {font-family: Tahoma; font-size: 11px;}
  textarea  {font-family: Tahoma; font-size: 11.5px;}
  a:visited {color: #0000FF;}

.tab-on {
padding: 2px;
border-top-width: 1px;
border-right-width: 1px;
border-bottom-width: 1px;
border-left-width: 1px;
border-top-style: solid;
border-right-style: none;
border-bottom-style: solid;
border-left-style: solid;
border-top-color: #cccccc;
border-right-color: #cccccc;
border-bottom-color: #cccccc;
border-left-color: #cccccc;
color: #000000;
background-color: #ffffff;
width: 100px;
}

.tab-onr {
padding: 2px;
border-top-width: 1px;
border-right-width: 1px;
border-bottom-width: 1px;
border-left-width: 1px;
border-top-style: solid;
border-right-style: solid;
border-bottom-style: solid;
border-left-style: solid;
border-top-color: #cccccc;
border-right-color: #cccccc;
border-bottom-color: #cccccc;
border-left-color: #cccccc;
color: #000000;
background-color: #ffffff;
width: 100px;
}

.tab-off
{
padding: 2px;
background-color: #f6f6f6;
color: #666666;
border-top: 1px solid #cccccc;
border-right: 1px none #cccccc;
border-bottom: 1px solid #cccccc;
border-left: 1px solid #cccccc;
width: 100px;
}

.tab-offr
{
padding: 2px;
background-color: #f6f6f6;
color: #666666;
border-top: 1px solid #cccccc;
border-right: 1px solid #cccccc;
border-bottom: 1px solid #cccccc;
border-left: 1px solid #cccccc;
width: 100px;
}

.tab-none
{
border-top-width: 1px;
border-right-width: 1px;
border-bottom-width: 1px;
border-left-width: 1px;
border-top-style: none;
border-right-style: none;
border-bottom-style: solid;
border-left-style: solid;
border-top-color: #cccccc;
border-right-color: #cccccc;
border-bottom-color: #cccccc;
border-left-color: #cccccc;
}

.show-table {display: block;}

.hide-table {display: none;}
-->
</style>

<script>
function switchCell(m) {
  var style;
  document.getElementById("navcell1").className = "tab-off";
  document.getElementById("navcell2").className = "tab-off";
  document.getElementById("navcell3").className = "tab-offr";
  document.getElementById("tb1").className = "hide-table";
  document.getElementById("tb2").className = "hide-table";
  document.getElementById("tb3").className = "hide-table";
  if(m == 3) {style = "tab-onr"} else {style = "tab-on"}
  document.getElementById("navcell" + m).className = style;
  document.getElementById("tb" + m).className = "tab-content show-table";
}
</script>
<title>RAPIDLEECH V2.2</title>
</head>

<body>
<script language="JavaScript">
function getCookie(name) {
  var dc = document.cookie;
  var prefix = name + "=";
  var begin = dc.indexOf("; " + prefix);
  if (begin == -1) {
    begin = dc.indexOf(prefix);
    if (begin != 0) return null;
  } else
    begin += 2;
  var end = document.cookie.indexOf(";", begin);
  if (end == -1)
    end = dc.length;
  return unescape(dc.substring(begin + prefix.length, end));
}

function deleteCookie(name, path, domain) {
  if (getCookie(name)) {
    document.cookie = name + "=" +
    ((path) ? "; path=" + path : "") +
    ((domain) ? "; domain=" + domain : "") +
    "; expires=Thu, 01-Jan-70 00:00:01 GMT";
  }
}
</script>
<center><img src="logo.gif" alt="RapidLeech" width="250" height="59" border="0">
</center><table align="center">
  <tbody>
  <tr>
    <td><table width="100%"  border="0">
      <tr>
        <td><table border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="131"><img src="links.gif" alt="links to check out" width="132" height="19" /></td>
          </tr>
          <tr>
            <td align="left" style="padding:3px;"><div align="left"><a href="http://www.rapidleech.com">RapidLeech.com</a><br />
					<a href="http://www.rapidleech.org">RapidLeech.org</a><br />
                    <a href="http://www.DirectProxy.com">DirectProxy.com</a><br>
                    <a href="http://www.Surftp.com">Surftp.com</a><br />
                    <a href="http://www.filevenue.com">FileVenue.com</a><br />
                    <a href="http://www.HitsBuilder.com">HitsBuilder.com</a>
                    <a href="http://www.adslab.com"><br>AdsLab.com</a><br />
            </div></td>
          </tr>
        </table>          </td>
      </tr>
      <tr>
        <td><table height="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="131" height="100%"><img src="currently_works_with.gif" alt="currently works with" width="131" height="19" /></td>
          </tr>
          <tr>
            <td height="100%" style="padding:3px;">RapidShare.de<br />RapidShare.com<br />Uploading.com<br />FileFactory.com<br />
      FileVenue.com<br />MegaUpload.com<br />Megarotic.com<br />MyTempDir.com<br />Getfile.biz<br />Webfile.ru</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td id="navcell1" align="center"> <a href="javascript:switchCell(1)"><img src="main_window.gif" border="0"></a> </td>
          <td id="navcell2" align="center"> <a href="javascript:switchCell(2)"><img src="settings.gif" border="0"></a> </td>
          <td id="navcell3" align="center"> <a href="javascript:switchCell(3)"><img src="server_files.gif" border="0"></a> </td>
        </tr>
      </tbody>
    </table>
      <table id="tb_content">
        <tbody>
        <tr>
          <td align="center">

            <table class="tab-content" id="tb1" name="tb" cellspacing="5" width="100%">
              <tbody>
              <tr>
                <td align="center">
                 <form action="<?php echo $PHP_SELF; ?>" method="post">
                  <p align="left"><b>Link to download:</b><br /> <input type="text" name="link" id="link" size="50">
                  
                  <p align="left"><b>Referrer:</b><br /> <input type="text" name="referer" id="referer" size="50">
                </td>
                <td align="center">
                  <input type="submit" value="Download File">
                </td>
              </tr>
              <tr>
                <td align="center">
                  <input type="checkbox" name="add_comment" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('comment').style.display=displ;">&nbsp;Add Comments
                </td>
              </tr>
              <tr id="comment" style="DISPLAY: none;">
                <td align="center">
                  <textarea name="comment" rows="4" cols="50"></textarea>
                </td>
              </tr>
              </tbody>
            </table>
            
            <table class="hide-table" id="tb2" name="tb" cellspacing="5" width="100%">
              <tbody>
              <tr>
                <td align="center">

                  <table align="center">
                    <tr>
                      <td>
                        <input type="checkbox" name="domail" id="domail" onClick="javascript:document.getElementById('emailtd').style.display=document.getElementById('splittd').style.display=this.checked?'':'none';document.getElementById('methodtd').style.display=(document.getElementById('splitchkbox').checked&this.checked)?'':'none';"<?php echo $_COOKIE["domail"] ? " checked" : ""; ?>>&nbsp;Send File to Email
                      </td>
                      <td>&nbsp;

                      </td>
                      <td id="emailtd"<?php echo $_COOKIE["domail"] ? "" : " style=\"display: none;\""; ?>>
                        Email:&nbsp;<input type="text" name="email" id="mail"<?php echo $_COOKIE["email"] ? " value=\"".$_COOKIE["email"]."\"" : ""; ?>>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      </td>
                    </tr>
                    <tr id="splittd"<?php echo $_COOKIE["split"] ? "" : " style=\"display: none;\""; ?>>
                      <td>
                        <input id="splitchkbox" type="checkbox" name="split" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('methodtd').style.display=displ;"<?php echo $_COOKIE["split"] ? " checked" : ""; ?>>&nbsp;Split Files
                      </td>
                      <td>&nbsp;

                      </td>
                      <td id="methodtd"<?php echo $_COOKIE["split"] ? "" : " style=\"display: none;\""; ?>>
                        <table>
                          <tr>
                            <td>
                              Method:&nbsp;<select name="method"><option value="tc"<?php echo $_COOKIE["method"] == "tc" ? " selected" : ""; ?>>Total Commander</option><option value=rfc<?php echo $_COOKIE["method"] == "rfc" ? " selected" : ""; ?>>RFC 2046</option></select>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              Parts Size:&nbsp;<input type="text" name="partSize" size="2" value=<?php echo $_COOKIE["partSize"] ? $_COOKIE["partSize"] : 10; ?>>&nbsp;MB
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="checkbox" id="useproxy" name="useproxy" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('proxy').style.display=displ;"<?php echo $_COOKIE["useproxy"] ? " checked" : ""; ?>>&nbsp;Use Proxy Settings
                      </td>
                      <td>&nbsp;

                      </td>
                      <td id="proxy"<?php echo $_COOKIE["useproxy"] ? "" : " style=\"display: none;\""; ?>>
                        <table width="150" border="0">
                          <tr><td>Proxy:&nbsp;</td><td><input type="text" name="proxy" id="proxy" size="20"<?php echo $_COOKIE["proxy"] ? " value=\"".$_COOKIE["proxy"]."\"" : ""; ?>></td></tr>
                          <tr><td>Username:&nbsp;</td><td><input type="text" name="proxyuser" id="proxyuser" size="20" <?php echo $_COOKIE["proxyuser"] ? " value=\"".$_COOKIE["proxyuser"]."\"" : ""; ?>></td></tr>
                          <tr><td>Password:&nbsp;</td><td><input type="text" name="proxypass" id="proxypass" size="20" <?php echo $_COOKIE["proxypass"] ? " value=\"".$_COOKIE["proxypass"]."\"" : ""; ?>></td></tr>
						</table>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="checkbox" name="rs_acc" id="rs_acc" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('rapidblock').style.display=displ;"<?php if (is_array($rs["de"]) || is_array($rs["com"])) print ' checked'; ?>>&nbsp;RS.de/com Premium Account
                      </td>
                      <td>&nbsp;</td>
                      <td id="rapidblock" style="display: none;">
                        <table width="150" border="0">
                         <tr><td>Username:&nbsp;</td><td><input type="text" name="rs_user" id="rlogin" size="15" value=""></td></tr>
                         <tr><td>Password:&nbsp;</td><td><input type="password" name="rs_pass" id="rpass" size="15" value=""></td></tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="checkbox" name="saveto" id="saveto" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('path').style.display=displ;"<?php echo $_COOKIE["saveto"] ? " checked" : ""; ?>>&nbsp;Save To
                      </td>
                      <td>&nbsp;

                      </td>
                      <td id="path"<?php echo $_COOKIE["saveto"] ? "" : " style=\"display: none;\""; ?>>
                        Path:&nbsp;<input type="text" name="path" size="30" value="<?php echo ($_COOKIE["path"] ? $_COOKIE["path"] : (strstr(realpath("./"), ":") ? addslashes(dirname(__FILE__)) : dirname(__FILE__))); ?>">
                      </td>
                    </tr>
                    <tr>
                      <td>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="checkbox" name="savesettings" id="savesettings"<?php echo $_COOKIE["savesettings"] ? " checked" : ""; ?> onClick="javascript:var displ=this.checked?'':'none';document.getElementById('clearsettings').style.display=displ;">&nbsp;Save Settings
                      </td>
                       <td>&nbsp;

                      </td>
                      <td id="clearsettings"<?php echo $_COOKIE["savesettings"] ? "" : " style=\"display: none;\""; ?>>
                        <script>
                          function clearSettings() {
                            clear("domail"); clear("email"); clear("split"); clear("method");
                            clear("partSize"); clear("useproxy"); clear("proxy"); clear("saveto");
                            clear("path"); clear("savesettings");

                            document.getElementById('domail').checked = false;
                            document.getElementById('splitchkbox').checked = false;
                            document.getElementById('useproxy').checked = false;
                            document.getElementById('rs_acc').checked = false;
                            document.getElementById('saveto').checked = false;
                            document.getElementById('savesettings').checked = false;

                            document.getElementById('email').value= "";
                            document.getElementById('proxy').value= "";
                            document.getElementById('proxyuser').value= "";
                            document.getElementById('proxypass').value= "";
                            document.getElementById('rs_user').value= "";
                            document.getElementById('rs_pass').value= "";
                            
                            document.getElementById('emailtd').style.display = "none";
                            document.getElementById('splittd').style.display = "none";
                            document.getElementById('methodtd').style.display = "none";
                            document.getElementById('proxy').style.display = "none";
                            document.getElementById('rapidblock').style.display = "none";
                            document.getElementById('path').style.display = "none";
                            document.getElementById('clearsettings').style.display = "none";

                            document.cookie = "clearsettings = 1;";
                          }

                          function clear(name) {
                            document.cookie = name + " = " + "; expires=Thu, 01-Jan-70 00:00:01 GMT";
                          }
                        </script>
                        <a href="javascript:clearSettings();">Clear Current Settings</a>
                      </td>
                    </tr>
                  </table>
                  </form>

                </td>
              </tr>
              </tbody>
            </table>

            <table class="hide-table" id="tb3" name="tb" cellspacing="5" width="100%" test>
              <tbody><?php echo $_GET["act"] ? "<script>switchCell(3);</script>" : "<script>switchCell(1);</script>"; ?>
                <td align="center" width="100%">
                  <?php
                  _create_list();
                  switch($_GET["act"])
                    {
                      case "delete":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Please select at least one file<br><br>";
                          }
                        else
                          {
                            ?>
                              <form method="post">
                              <input type="hidden" name="act" value="delete_go">
                              File<?php echo count($_GET["files"]) > 1 ? "s" : ""; ?>:
                              <?php
                              for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                  $file = $list[$_GET["files"][$i]];
                                  ?>
                                  <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                  <b><?php echo basename($file["name"]); ?></b><?php echo $i == count($_GET["files"]) - 1 ? "." : ",&nbsp"; ?>
                                  <?php
                                }
                              ?><br>Delete<?php echo count($_GET["files"]) > 1 ? " These Files" : " This File"; ?>?<br>
                              <table>
                                <tr>
                                  <td>
                                    <input type="submit" name="yes" style="width:33px; height:23px" value="Yes">
                                  </td>
                                  <td>
                                    &nbsp;&nbsp;&nbsp;
                                  </td>
                                  <td>
                                    <input type="submit" name="no" style="width:33px; height:23px" value="No">
                                  </td>
                                </tr>
                              </table>
                              </form>
                            <?php
                          }
                      break;

                      case "delete_go":
                        if($_GET["yes"])
                          {
                            for($i = 0; $i < count($_GET["files"]); $i++)
                              {
                                $file = $list[$_GET["files"][$i]];
                                if(file_exists($file["name"]))
                                  {
                                    if(@unlink($file["name"]))
                                      {
                                        echo "File <b>".$file["name"]."</b> Deleted<br><br>";
                                        unset($list[$_GET["files"][$i]]);
                                      }
                                    else
                                      {
                                        echo "Error deleting the file <b>".$file["name"]."</b>!<br><br>";
                                      }
                                  }
                                else
                                  {
                                    echo "File <b>".$file["name"]."</b> Not Found!<br><br>";
                                  }
                              }
                            if(!updateListInFile($list))
                              {
                                  echo "Error in updating the list!<br><br>";
                              }
                          }
                        else
                          {
                            ?>
                              <script>
                                location.href="<?php echo substr($PHP_SELF, 0, strlen($PHP_SELF) - strlen(strstr($PHP_SELF, "?")))."?act=files"; ?>";
                              </script>
                            <?php
                          }
                      break;

                      case "mail":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                              <form method="post">
                              <input type="hidden" name="act" value="mail_go">
                              File<?php echo count($_GET["files"]) > 1 ? "y" : ""; ?>:
                              <?php
                              for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                  $file = $list[($_GET["files"][$i])];
                                  ?>
                                  <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                  <b><?php echo basename($file["name"]); ?></b><?php echo $i == count($_GET["files"]) - 1 ? "." : ",&nbsp"; ?>
                                  <?php
                                }
                              ?><br><br>
                              <table align="center">
                                <tr>
                                  <td>
                                    Email:&nbsp;<input type="text" name="email" value="<?php echo ($_COOKIE["email"] ? $_COOKIE["email"] : ""); ?>">
                                  </td>
                                  <td>
                                    <input type="submit" value="Send">
                                  </td>
                                </tr>
                                <tr>
                                 <td>
                                    <input type="checkbox" name="del_ok" checked>&nbsp;Delete successful submits
                                 </td>
                                </tr>
                                <tr>
                                  <td>
                                  </td>
                                </tr>
                                <tr>
                                  <table>
                                    <tr>
                                      <td>
                                        <input id="splitchkbox" type="checkbox" name="split" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('methodtd2').style.display=displ;"<?php echo $_COOKIE["split"] ? " checked" : ""; ?>>&nbsp;Split by Parts
                                      </td>
                                      <td>&nbsp;

                                      </td>
                                      <td id="methodtd2"<?php echo $_COOKIE["split"] ? "" : " style=\"display: none;\""; ?>>
                                        <table>
                                          <tr>
                                            <td>
                                              Method:&nbsp;<select name="method"><option value="tc"<?php echo $_COOKIE["method"] == "tc" ? " selected" : ""; ?>>Total Commander</option><option value="rfc"<?php echo $_COOKIE["method"] == "rfc" ? " selected" : ""; ?>>RFC 2046</option></select>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                              Parts Size:&nbsp;<input type="text" name="partSize" size="2" value="<?php echo $_COOKIE["partSize"] ? $_COOKIE["partSize"] : 10; ?>">&nbsp;MB
                                            </td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                              </form>
                            <?php
                          }
                      break;

                      case "mail_go":
                        if(!checkmail($_GET["email"]))
                          {
                            echo "Invalid E-mail Address.<br><br>";
                          }
                        else
                          {
                            ?>
                              <script>
                                function mail(str, field) {
                                  document.getElementById("mailPart." + field).innerHTML = str;
                                  return true;
                                }
                              </script>
                            <?php
                            $_GET["partSize"] = ((isset($_GET["partSize"]) & $_GET["split"] == "on") ? $_GET["partSize"] * 1024 * 1024 : FALSE);
                            for($i = 0; $i < count($_GET["files"]); $i++)
                              {
                                $file = $list[$_GET["files"][$i]];
                                if(file_exists($file["name"]))
                                  {
                                    if(xmail("$fromaddr", $_GET[email], "File ".basename($file["name"]), "File: ".basename($file["name"])."\r\n"."Link: ".$file["link"].($file["comment"] ? "\r\nComments: ".str_replace("\\r\\n", "\r\n", $file["comment"]) : ""), $file["name"], $_GET["partSize"], $_GET["method"]))
                                      {
                                       if ($_GET["del_ok"])
                                          {
                                           if(@unlink($file["name"]))
                                             {
                                              $v_ads=" and deleted.";
                                              unset($list[$_GET["files"][$i]]);
                                             }
                                           else
                                             {
                                              $v_ads=", but <b>not deleted!</b>";
                                             };
                                          } else $v_ads=" !";
                                        echo "<script>mail('File <b>".basename($file["name"])."</b> it is sent for the address <b>".$_GET["email"]."</b>".$v_ads."', '".md5(basename($file["name"]))."');</script>\r\n<br>";
                                      }
                                    else
                                      {
                                        echo "Error sending file!<br>";
                                      }
                                  }
                                else
                                  {
                                    echo "File <b>".$file["name"]."</b> not found!<br><br>";
                                  }
                              }
                          }
                      break;

                      case "boxes":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                              <form method="post">
                              <input type="hidden" name="act" value="boxes_go">
                              <?php
                             echo count($_GET["files"])." file".(count($_GET["files"]) > 1 ? "s" : "").":<br>";
                              for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                  $file = $list[($_GET["files"][$i])];
                                  ?>
                                  <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                  <b><?php echo basename($file["name"]); ?></b><?php echo $i == count($_GET["files"]) - 1 ? "." : ",&nbsp"; ?>
                                  <?php
                                }
                              ?><br><br>
                              <table align="center">
                                <tr>
                                  <td>
                                    Emails:&nbsp;<textarea name="emails" cols="30" rows="8"><?php if ($_COOKIE["email"]) echo $_COOKIE["email"]; ?></textarea>
                                  </td>
                                  <td>
                                    <input type="submit" value="Send">
                                  </td>
                                </tr>
                                <tr>
                                 <td>
                                    <input type="checkbox" name="del_ok" checked>&nbsp;Delete successful submits
                                 </td>
                                </tr>
                                <tr>
                                 <td>
                                 </td>
                                </tr>
                                <tr>
                                  <table>
                                    <tr>
                                      <td>
                                        <input id="splitchkbox" type="checkbox" name="split" onClick="javascript:var displ=this.checked?'':'none';document.getElementById('methodtd2').style.display=displ;"<?php echo $_COOKIE["split"] ? " checked" : ""; ?>>&nbsp;Split by Parts
                                      </td>
                                      <td>&nbsp;

                                      </td>
                                      <td id=methodtd2<?php echo $_COOKIE["split"] ? "" : " style=\"display: none;\""; ?>>
                                        <table>
                                          <tr>
                                            <td>
                                              Method:&nbsp;<select name="method"><option value="tc"<?php echo $_COOKIE["method"] == "tc" ? " selected" : ""; ?>>Total Commander</option><option value="rfc"<?php echo $_COOKIE["method"] == "rfc" ? " selected" : ""; ?>>RFC 2046</option></select>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                              Parts Size:&nbsp;<input type="text" name="partSize" size="2" value="<?php echo ($_COOKIE["partSize"] ? $_COOKIE["partSize"] : 10); ?>">&nbsp;MB
                                            </td>
                                          </tr>
                                        </table>
                                      </td>
                                    </tr>
                                  </table>
                              </form>
                            <?php
                          }
                      break;

                      case "boxes_go":
                          {
                            ?>
                              <script>
                                function mail(str, field) {
                                  document.getElementById("mailPart." + field).innerHTML = str;
                                  return true;
                                }
                              </script>
                            <?php
                            $_GET["partSize"] = ((isset($_GET["partSize"]) & $_GET["split"] == "on") ? $_GET["partSize"] * 1024 * 1024 : FALSE);
                            $v_mails = explode("\n",$emails);
                            $v_min=count((count($_GET["files"])<count($v_mails)) ? $_GET["files"] : $v_mails);

                            for($i = 0; $i < $v_min; $i++)
                              {
                                $file = $list[$_GET["files"][$i]];

                                $v_mail = trim($v_mails[$i]);
                              if(!checkmail($v_mail))
                               {
                                echo "<b>$v_mail</b> - Invalid E-mail Address.<br><br>";
                               }
                              elseif(file_exists($file["name"]))
                                  {
                                    if(xmail("$fromaddr", $v_mail, "File ".basename($file["name"]), "File: ".basename($file["name"])."\r\n"."Link: ".$file["link"].($file["comment"] ? "\r\nComments: ".str_replace("\\r\\n", "\r\n", $file["comment"]) : ""), $file["name"], $_GET["partSize"], $_GET["method"]))
                                      {
                                        if ($_GET["del_ok"])
                                          {
                                           if(@unlink($file["name"]))
                                             {
                                              $v_ads=" and deleted !";
                                              unset($list[$_GET["files"][$i]]);
                                             }
                                           else
                                             {
                                              $v_ads=", but <b>not deleted !</b>";
                                             };
                                          } else $v_ads=" !";
                                        echo "<script>mail('File <b>".basename($file["name"])."</b> it is sent for the address <b>".$v_mail."</b>".$v_ads."', '".md5(basename($file["name"]))."');</script>\r\n<br>";
                                      }
                                    else
                                      {
                                        echo "Error sending file!<br>";
                                      }
                                  }
                                else
                                  {
                                    echo "File <b>".$file["name"]."</b> Not Found!<br><br>";
                                  }
                              }

                             if (count($_GET["files"])<count($v_mails))
                              {
                               echo "<b>��������!</b> �� �������� ������ ������.<br><br><b>";
                               for($i = count($_GET["files"]); $i < count($v_mails); $i++)
                                {
                                  $v_mail = trim($v_mails[$i]);
                                  echo "$v_mail.</b><br><br>";
                                };
                                echo "</b><br>";
                              }
                         elseif (count($_GET["files"])>count($v_mails))
                              {
                               echo "<b>��������!</b> �� �� �������� ������ ��� ��������� ������:<br><br><b>";
                               for($i = count($v_mails); $i < count($_GET["files"]); $i++)
                                {
                                $file = $list[$_GET["files"][$i]];
                                if(file_exists($file["name"]))
                                  {
                                    echo $file["name"]."<br><br>";
                                  }
                                else
                                  {
                                    echo "</b>���� <b>".$file["name"]."</b> �� ������!<b><br><br>";
                                  }
                                }
                               echo "</b><br>";
                              };

                           if ($_GET["del_ok"])
                            {
                             if(!updateListInFile($list))
                               {
                                  echo "Couldn't Update!<br><br>";
                               }
                            }

                          }
                      break;

                      case "split":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                            <form method="post">
                              <input type="hidden" name="act" value="split_go">
                               <table align="center">
                                <tr>
                                  <td>
                                    <table>
                              <?php
                                for($i = 0; $i < count($_GET["files"]); $i++)
                                  {
                                    $file = $list[$_GET["files"][$i]];
                                    ?>
                                      <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                          <tr>
                                            <td align="center"><b><?php echo basename($file["name"]); ?></b></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              Parts Size:&nbsp;<input type="text" name="partSize[]" size="2" value="<?php echo ($_COOKIE["partSize"] ? $_COOKIE["partSize"] : 10); ?>">&nbsp;MB
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                              Save To:&nbsp;<input type="text" name="saveTo[]" size="40" value="<?php echo addslashes(dirname($file["name"])); ?>">
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                              <input type="checkbox" name="del_ok" checked>&nbsp;Delete source file after successful split
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                            </td>
                                          </tr>
                                    <?php
                                  }
                              ?>
                                    </table>
                                  </td>
                                  <td>
                                    <input type="submit" value="Split">
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                  </td>
                                </tr>
                              </table>
                            </form>
                            <?php
                          }
                      break;

                      case "split_go":
                        for($i = 0; $i < count($_GET["files"]); $i++)
                          {
                            $split_ok = true;
                            $file = $list[$_GET["files"][$i]];
                            $partSize = urldecode($_GET["partSize"][$i]) * 1024 * 1024;
                            $saveTo = stripslashes(urldecode($_GET["saveTo"][$i]));
                            $partSize = round($partSize);
                            $fileContents = read_file($file["name"]);
                            $fileSize = strlen($fileContents);
                            $crc = strtoupper(dechex(crc32($fileContents)));
                            $crc = str_repeat("0", 8 - strlen($crc)).$crc;
                            if(file_exists($file["name"]))
                              {
                            echo "Started to split file <b>".basename($file["name"])."</b> of parts ".bytesToKbOrMbOrGb($partSize).", Using Method - Total Commander...<br>";
                            $totalParts = ceil($fileSize / $partSize);
                            echo "Total Parts: <b>".$totalParts."</b><br><br>";
                            $fileTmp = $fileNamePerman = basename($file["name"]);
                            while(strpos($fileTmp, "."))
                              {
                                $fileName .= substr($fileTmp, 0, strpos($fileTmp, ".") + 1);
                                $fileTmp = substr($fileTmp, strpos($fileTmp, ".") + 1);
                              }
                            $fileName = substr($fileName, 0, -1);
                            $path = stripslashes($saveTo.(strstr(realpath("./"), ":") ? "\\\\" : "/"));
                            for($j = 0; $j < $totalParts; $j++)
                              {
                                if($j == 0)
                                  {
                                    $fileChunk = substr($fileContents, 0, $partSize);
                                    if(!@write_file($path.$fileName.".crc", "filename=".basename($file["name"])."\r\n"."size=".$fileSize."\r\n"."crc32=".$crc."\r\n"))
                                      {
                                        echo "It is not possible to split the file. CRC Error<b>".$fileName.".crc"."</b> !<br><br>";
                                        $split_ok=false;
                                      }
                                    else
                                      {
                                        $time = explode(" ", microtime());
                                        $time = str_replace("0.", $time[1], $time[0]);
                                        $list[$time] = array("name"    => $path.$fileName.".crc",
                                                             "size"    => bytesToKbOrMbOrGb(strlen(read_file($path.$fileName.".crc"))),
                                                             "date"    => time(),
                                                             "comment" => "CRC file of ".$fileNamePerman);
                                      }
                                    if(!@write_file($path.$fileName.".001", $fileChunk))
                                      {
                                        echo "It was not possible to split the file <b>".$fileName.".001"."</b> !<br><br>";
                                        $split_ok=false;
                                      }
                                    else
                                      {
                                        $time = explode(" ", microtime());
                                        $time = str_replace("0.", $time[1], $time[0]);
                                        $list[$time] = array("name"    => $path.$fileName.".001",
                                                             "size"    => bytesToKbOrMbOrGb(strlen($fileChunk)),
                                                             "date"    => time(),
                                                             "comment" => "Part ".($j + 1)."/".$totalParts." of ".$fileNamePerman);
                                      }
                                  }
                                elseif($j == $totalParts - 1)
                                  {
                                    $fileChunk = substr($fileContents, $j * $partSize);
                                    $num = strlen($j + 1) == 2 ? "0".($j + 1) : (strlen($j + 1) == 1 ? "00".($j + 1) : ($j + 1));
                                    if(!@write_file($path.$fileName.".".$num, $fileChunk))
                                      {
                                        echo "It was not possible to split the file <b>".$fileName.".".$num."</b> !<br><br>";
                                        $split_ok = false;
                                      }
                                    else
                                      {
                                        $time = explode(" ", microtime());
                                        $time = str_replace("0.", $time[1], $time[0]);
                                        $list[$time] = array("name"    => $path.$fileName.".".$num,
                                                             "size"    => bytesToKbOrMbOrGb(strlen($fileChunk)),
                                                             "date"    => time(),
                                                             "comment" => "Part ".($j + 1)."/".$totalParts." of ".$fileNamePerman);
                                      }
                                  }
                                else
                                  {
                                    $fileChunk = substr($fileContents, $j * $partSize, $partSize);
                                    $num = strlen($j + 1) == 2 ? "0".($j + 1) : (strlen($j + 1) == 1 ? "00".($j + 1) : ($j + 1));
                                    if(!@write_file($path.$fileName.".".$num, $fileChunk))
                                      {
                                      echo "It was not possible to split the file <b>".$fileName.".".$num."</b> !<br><br>";
                                      $split_ok = false;
                                      }
                                    else
                                      {
                                      $time = explode(" ", microtime());
                                      $time = str_replace("0.", $time[1], $time[0]);
                                      $list[$time] = array("name"    => $path.$fileName.".".$num,
                                                           "size"    => bytesToKbOrMbOrGb(strlen($fileChunk)),
                                                           "date"    => time(),
                                                           "comment" => "Part ".($j + 1)."/".$totalParts." of ".$fileNamePerman);
                                      }
                                  }
                              }
                            unset($fileName);
                            if ($_GET["del_ok"])
                             {
                               if (!$split_ok )
                                {
                                 echo "An error occured. Source file not deleted!<br><br>";
                                }
                           elseif(@unlink($file["name"]))
                                {
                                  unset($list[$_GET["files"][$i]]);
                                  echo "Source file deleted.<br><br>";
                                }
                               else
                                {
                                 echo "Source file is<b>not deleted!</b><br><br>";
                                };
                             };
                            if(!updateListInFile($list))
                              {
                                  echo "Couldn't update. File already exists!<br><br>";
                              }
                             } //if(file_exists($file["name"]))
                          }
                      break;

                      case "merge":
						if (count($_GET["files"]) !== 1)
							{
							echo "Please select only the .crc file!<br><br>";
							}
						else
							{
							$file = $list[$_GET["files"][0]];
							if (substr($file["name"], -4) !== ".crc")
								{
								echo "Please select the .crc file!<br><br>";
								}
							else
								{
								$fs = @fopen($file["name"], "rb");
								if (!$fs)
									{
									echo "Can't read the .crc file!<br><br>";
									}
								else
									{
									flock($fs, LOCK_SH);
									while(!feof($fs))
										{
										$data .= trim(fgets($fs, 1024));
										if ($data === false) {break;}
										}
									flock($fs, LOCK_UN);
									fclose($fs);
									$tmp = explode("=", $data);
									$crc = array($tmp[0] => substr($tmp[1],0,-4), substr($tmp[1],-4) => substr($tmp[2],0,-5), substr($tmp[2],-5) => $tmp[3]);
									$dir = dir("./");
									$f = substr($crc["filename"], 0, strrpos($crc["filename"], "."));
									while(($file = $dir->read()) !== false)
										{
										if (ereg("$f.([0-9]{3})", $file))
											{
											$files[]= realpath($file);
											}
										}
									/*
									foreach (glob(substr($crc["filename"], 0, strrpos($crc["filename"], ".")).".*") as $fn)
										{
										if (ereg(".([0-9]{3})", substr($fn, -4)))
											{
											$files[]= $fn;
											}
										}
									*/
									$dir->close();
									if (!is_array($files))
										{
										echo "The files needed to merge are not found!<br><br>";
										}
									else
										{
										$fs = @fopen($crc["filename"], "wb");
										if (!$fs)
											{
											echo "The file can't be opened for writing!<br><br>";
											}
										else
											{
											flock($fs, LOCK_EX);
											foreach ($files as $fn)
												{
												$fp = @fopen($fn, "rb");
												flock($fp, LOCK_SH);
												while (!feof($fp))
													{
													$data = fgets($fp, 1024);
													if ($data === false) {break;}
													else {fwrite($fs, $data);}
													}
												flock($fp, LOCK_UN);
												fclose($fp);
												}
											flock($fs, LOCK_UN);
											fclose($fs);
											$fs = filesize($crc["filename"]);
											if ($fs != $crc["size"])
												{
												echo "Filesize doesn't match!<br><br>";
												}
											else
												{
												?>
<form method="post">
<input type="hidden" name="act" value="merge_go">
<input type="hidden" name="filename" value="<?php echo $crc["filename"]; ?>">
<input type="hidden" name="path" value="<?php echo dirname($file["name"]); ?>">
<input type="hidden" name="size" value="<?php echo $crc["size"]; ?>">
<input type="hidden" name="crc32" value="<?php echo $crc["crc32"]; ?>">
Do you want to perform a CRC check?<br>(recommended)<br>
<table>
<tr>
<td>
<input type="submit" name="yes" style="width:33px; height:23px" value="Yes">
</td>
<td>
&nbsp;&nbsp;&nbsp;
</td>
<td>
<input type="submit" name="no" style="width:33px; height:23px" value="No">
</td>
</tr>
</table>
</form>
												<?php
												}
											}
										}
									}
								}
							}
                      break;
                      
                      case "merge_go":
						if ($_POST["yes"])
							{
							$fileContents = read_file($_POST["filename"]);
							$fc = strtoupper(dechex(crc32($fileContents)));
							$fc = str_repeat("0", 8 - strlen($fc)).$fc;
							if ($fc != $_POST["crc32"])
								{
								echo "CRC32 checksum doesn't match!<br><br>";
								}
							else
								{
								echo "File <b>".$_POST["filename"]."</b> successfully merged!<br><br>";
								$time = explode(" ", microtime());
								$time = str_replace("0.", $time[1], $time[0]);
								$list[$time] = array("name"    => $_POST["path"].(strstr(realpath("./"), ":") ? "\\" : "/").$_POST["filename"],
													 "size"    => bytesToKbOrMbOrGb($_POST["size"]),
													 "date"    => time());
								if (!updateListInFile($list))
									{
									echo "Couldn't update the list. File already exists!<br><br>";
									}
								}
							}
						else
							{
							echo "File <b>".$_POST["filename"]."</b> successfully merged, but not tested!<br><br>";
							$time = explode(" ", microtime());
							$time = str_replace("0.", $time[1], $time[0]);
							$list[$time] = array("name"    => $_POST["path"].(strstr(realpath("./"), ":") ? "\\" : "/").$_POST["filename"],
												 "size"    => bytesToKbOrMbOrGb($_POST["size"]),
												 "date"    => time());
							if (!updateListInFile($list))
								{
								echo "Couldn't update the list. File already exists!<br><br>";
								}
							}
                      break;
                      
                      case "rename":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                            <form method="post">
                              <input type="hidden" name="act" value="rename_go">
                               <table align="center">
                                <tr>
                                  <td>
                                    <table>
                              <?php
                                for($i = 0; $i < count($_GET["files"]); $i++)
                                  {
                                    $file = $list[$_GET["files"][$i]];
                                    ?>
                                      <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                          <tr>
                                            <td align="center"><b><?php echo basename($file["name"]); ?></b></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              New name:&nbsp;<input type="text" name="newName[]" size="25" value="<?php echo basename($file["name"]); ?>">
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>
                                            </td>
                                          </tr>
                                    <?php
                                  }
                              ?>
                                    </table>
                                  </td>
                                  <td>
                                    <input type="submit" value="Rename">
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                  </td>
                                </tr>
                              </table>
                            </form>
                            <?php
                          }
                      break;

                      case "rename_go":
                         $smthExists = FALSE;
                         for($i = 0; $i < count($_GET["files"]); $i++)
                          {
                            $file = $list[$_GET["files"][$i]];
                            if(file_exists($file["name"]))
                              {
                                $smthExists = TRUE;
                                $newName = dirname($file["name"]).PATH_SPLITTER.$_GET["newName"][$i];
                                if(@rename($file["name"], $newName))
                                  {
                                    echo "File <b>".$file["name"]."</b> Renamed to<b>".basename($newName)."</b><br><br>";
                                    $list[$_GET["files"][$i]]["name"] = $newName;
                                  }
                                else
                                  {
                                    echo "Couldn't rename the file <b>".$file["name"]."</b>!<br><br>";
                                  }
                              }
                            else
                             {
                               echo "File <b>".$file["name"]."</b> Not Found!<br><br>";
                             }
                          }
                         if($smthExists)
                           {
                             if(!updateListInFile($list))
                              {
                                  echo "Couldn't Update<br><br>";
                              }
                           }
                      break;

                      case "ftp":
                        if(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                              <form method="post">
                              <input type="hidden" name="act" value="ftp_go">
                              File<?php echo count($_GET["files"]) > 1 ? "y" : ""; ?>:
                              <?php
                              for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                  $file = $list[($_GET["files"][$i])];
                                  ?>
                                  <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                  <b><?php echo basename($file["name"]); ?></b><?php echo $i == count($_GET["files"]) - 1 ? "." : ",&nbsp"; ?>
                                  <?php
                                }
                              ?><br><br>
                              <table align="center">
                                <tr>
                                  <td>
                                    <table>
                                      <tr>
                                        <td>
                                          Host:
                                        </td>
                                        <td>
                                          <input type="text" name="host" id="host"<?php echo $_COOKIE["host"] ? " value=\"".$_COOKIE["host"]."\"" : ""; ?> size="23">
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                         Port:
                                        </td>
                                        <td>
                                          <input type="text" name="port" id="port"<?php echo $_COOKIE["port"] ? " value=\"".$_COOKIE["port"]."\"" : " value=\"21\""; ?> size="4">
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Username:
                                        </td>
                                        <td>
                                          <input type="text" name="login" id="login"<?php echo $_COOKIE["login"] ? " value=\"".$_COOKIE["login"]."\"" : ""; ?> size="23">
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Password:
                                        </td>
                                        <td>
                                          <input type="password" name="password" id="password"<?php echo $_COOKIE["password"] ? " value=\"".$_COOKIE["password"]."\"" : ""; ?> size="23">
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          Directory:
                                        </td>
                                        <td>
                                          <input type="text" name="dir" id="dir"<?php echo $_COOKIE["dir"] ? " value=\"".$_COOKIE["dir"]."\"" : " value=\"/\""; ?>  size="23">
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          <input type="checkbox" name="del_ok">&nbsp;Delete source file after successful upload
                                        </td>
                                      </tr>
                                    </table>
                                  </td>
                                  <td>&nbsp;

                                  </td>
                                  <td>
                                    <table>
                                      <tr align="center">
                                        <td>
                                          <input type="submit" value="Upload">
                                        </td>
                                      </tr>
                                      <tr align="center">
                                        <td>
                                          Options
                                        </td>
                                      </tr>
                                      <tr align="center">
                                        <td>
                                          <script language="JavaScript">
                                          function setFtpParams() {
                                            setParam("host"); setParam("port"); setParam("login");
                                            setParam("password"); setParam("dir");
                                            document.cookie = "ftpParams=1";
                                            document.getElementById("hrefSetFtpParams").style.color = "#808080";
                                            document.getElementById("hrefDelFtpParams").style.color = "#0000FF";
                                          }

                                          function delFtpParams() {
                                            deleteCookie("host"); deleteCookie("port"); deleteCookie("login");
                                            deleteCookie("password"); deleteCookie("dir"); deleteCookie("ftpParams");
                                            document.getElementById("hrefSetFtpParams").style.color = "#0000FF";
                                            document.getElementById("hrefDelFtpParams").style.color = "#808080";
                                          }

                                          function setParam(param) {
                                            document.cookie = param + "=" + document.getElementById(param).value;
                                          }

                                          document.write(
                                            '<a href="javascript:setFtpParams();" id="hrefSetFtpParams" style="color: ' + (getCookie('ftpParams') == 1 ? '#808080' : '#0000FF') + ';">Copy Files</a> | ' +
                                            '<a href="javascript:delFtpParams();" id="hrefDelFtpParams" style="color: ' + (getCookie('ftpParams') == 1 ? '#0000FF' : '#808080') + '";">Move Files</a>'
                                          );
                                          </script>
                                        </td>
                                      </tr>
                                    </table>
                                  </td>
                                </tr>
                              </table>
                              </form>
                            <?php
                          }
                      break;

                      case "ftp_go":
                        $ftp = new ftp();
                        if(!$ftp->SetServer($_POST["host"], (int)$_POST["port"]))
                          {
                              $ftp->quit();
                              echo "Couldn't connect to the server".$_POST["host"].":".$_POST["port"].".<br>".
                                   "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
                          }
                        else
                          {
                              if(!$ftp->connect())
                                {
                                    $ftp->quit();
                                    echo "<br>Couldn't connect to the server ".$_POST["host"].":".$_POST["port"].".<br>".
                                         "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
                                }
                              else
                                {
									echo "Connected to: <b>".$_POST["host"]."</b>...";
                                    if (!$ftp->login($_POST["login"], $_POST["password"]))
                                      {
                                          $ftp->quit();
                                          echo "<br>Wrong username and/or password <b>".$_POST["login"].":".$_POST["password"]."</b>.<br>".
                                                "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
                                      }
                                    else
                                      {
										  $ftp->Passive(FALSE);
                                          if(!$ftp->chdir($_POST["dir"]))
                                            {
                                                $ftp->quit();
                                                echo "<br>Cannot locate the folder<b>".$_POST["dir"]."</b>.<br>".
                                                      "<a href=\"javascript:history.back(-1);\">Go Back</a><br><br>";
                                            }
                                          else
                                            {
                                                ?>
<br>
<div id="status"></div><br>
<table cellspacing="0" cellpadding="0" style="FONT-FAMILY: Tahoma; FONT-SIZE: 11px;">
<tr>
<td></td>
<td>
<div style='border:#BBBBBB 1px solid; width:300px; height:10px;'>
<div id="progress" style='background-color:#000099; margin:1px; width:0%; height:8px;'>
</div>
</div>
</td>
<td></td>
<tr>
<tr>
<td align="left" id="received">0 KB</td>
<td align="center" id="percent">0%</td>
<td align="right" id="speed">0 KB/s</td>
</tr>
</table>
<script>
function pr(percent, received, speed) {
	document.getElementById("received").innerHTML = '<b>' + received + '</b>';
	document.getElementById("percent").innerHTML = '<b>' + percent + '%</b>';
	document.getElementById("progress").style.width = percent + '%';
	document.getElementById("speed").innerHTML = '<b>' + speed + ' KB/s</b>';
	document.title = 'Uploaded ' + percent + '%';
	return true;
	}

function changeStatus(file, size) {
	document.getElementById("status").innerHTML = 'Uploading File <b>' + file + '</b>, Size <b>' + size + '</b>...<br>';
	}
</script>
<br>
<?php
                                                $FtpUpload = TRUE;
                                                for($i = 0; $i < count($_GET["files"]); $i++)
                                                  {
                                                      $file = $list[$_GET["files"][$i]];
                                                      echo "<script>changeStatus('".basename($file["name"])."', '".$file["size"]."');</script>";
                                                      $FtpBytesTotal = filesize($file["name"]);
                                                      $FtpChunkSize = round($FtpBytesTotal / 333);
                                                      $FtpTimeStart = getmicrotime();
                                                      if($ftp->put($file["name"], basename($file["name"])))
                                                        {
                                                            $time = round(getmicrotime() - $FtpTimeStart);
                                                            $speed = round($FtpBytesTotal / 1024 / $time, 2);
                                                            echo "<script>pr(100, '".bytesToKbOrMbOrGb($FtpBytesTotal)."', ".$speed.")</script>\r\n";
                                                            flush();

                                                            if($_GET["del_ok"])
                                                             {
                                                              if(@unlink($file["name"]))
                                                               {
                                                                $v_ads=" and deleted ";
                                                                unset($list[$_GET["files"][$i]]);
                                                               }
                                                              else
                                                               {
                                                                $v_ads=", but <b>not deleted </b>";
                                                               };
                                                             } else $v_ads="";

                                                            echo "File <a href=\"ftp://".$_POST["login"].":".$_POST["password"]."@".$_POST["host"].":".$_POST["port"].
                                                                  $_POST["dir"]."/".basename($file["name"])."\"><b>".basename($file["name"])."</b></a> successfully uploaded$v_ads!".
                                                                  "<br>Time: <b>".sec2time($time)."</b><br>Average speed: <b>".$speed." KB/s</b><br><br>";
                                                        }
                                                      else
                                                        {
                                                            echo "Couldn't upload the file <b>".basename($file["name"])."</b>!<br>";
                                                        }
                                                  }
                                                $ftp->quit();
                                            }
                                      }
                                }

                          }
                      break;
                      
                      case "zip":
                       if (count($_GET["files"]) < 1)
							{
							echo "Select at least one file.<br><br>";
							}
						else
							{
							for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                $file[]= $list[($_GET["files"][$i])];
                                }
						print "What do you want to do?<br><br>";
						?>
<script language="JavaScript">
function zip() {
	var i = document.ziplist.act.selectedIndex;
	var selected = document.ziplist.act.options[i].value;
	document.getElementById('add').style.display = 'none';
	switch (selected)
		{
		case "zip_add":
			document.getElementById('add').style.display = 'block';
		break;
		//case "zip_extract":
			
		//break;
		//case "zip_list":
			//void(document.ziplist.submit());
		//break;
		}
	}
</script>
<form name="ziplist" method="post">
<table cellspacing="5">
<tr>
<td align="center">
<select name="act" id="act" onChange="zip();">
<option selected>Select an Action</option>
<option value="zip_add">Add files to a ZIP archive</option>
</select>
</td>
<td>
</td>
<td id="add" align="center" style="DISPLAY: none;">
<table>
<tr><td>Archive Name:&nbsp;<input type="text" name="archive" size="25" value=".zip"><br></td></tr>
<tr><td><input type="checkbox" name="no_compression">&nbsp;Do not use compression<br></td></tr>
<tr><td><input type="checkbox" name="remove_path">&nbsp;Do not include directories<br></td></tr>
</table>
<table>
<tr><td><input type="submit" value="Add Files"></td></tr>
</table>
</td>
</tr>
</table>
<?php
                        echo "<br>Selected File".(count($_GET["files"]) > 1 ? "s" : "").": ";
                        for($i = 0; $i < count($_GET["files"]); $i++)
							{
                            $file = $list[($_GET["files"][$i])];
                            print "<input type=\"hidden\" name=\"files[]\" value=\"{$_GET[files][$i]}\">\r\n";
                            echo "<b>".basename($file["name"])."</b>";
                            echo ($i == count($_GET["files"]) - 1) ? "." : ",&nbsp;";
                            }
                        ?>
</form>
<?php
							}
                      break;
                      
                      case "zip_add":
						$_GET["archive"] = (strlen(trim(urldecode($_GET["archive"]))) > 4 && substr(trim(urldecode($_GET["archive"])), -4) == ".zip") ? trim(urldecode($_GET["archive"])) : "archive.zip";
						for($i = 0; $i < count($_GET["files"]); $i++)
							{
							$files[]= $list[($_GET["files"][$i])];
							}
						foreach ($files as $file)
							{
							$CurrDir = realpath("./");
							$inCurrDir = stristr(dirname($file["name"]), $CurrDir) ? TRUE : FALSE;
							if ($inCurrDir)
								{
								$add_files[]= substr($file["name"], (strlen($CurrDir) + 1));
								}
							}
						require_once('pclzip.php');
						$archive = new PclZip($_GET["archive"]);
						$no_compression = ($_GET["no_compression"] == "on") ? PCLZIP_OPT_NO_COMPRESSION : 77777;
						$remove_path = ($_GET["remove_path"] == "on") ? PCLZIP_OPT_REMOVE_ALL_PATH : 77777;
						if (file_exists($_GET["archive"]))
							{
							$v_list = $archive->add($add_files, $no_compression, $remove_path);
							}
						else
							{
							$v_list = $archive->create($add_files, $no_compression, $remove_path);
							}
						if ($v_list == 0) {
							echo "Error: ".$archive->errorInfo(true)."<br><br>";
							}
						else {
							echo "Archive <b>".$_GET["archive"]."</b> successfully created!<br><br>";
							}
					  break;
                      
                      case "pack":
                       if (!file_exists("Tar.php") || !file_exists("PEAR.php"))
                          { echo "Components \"Tar.php\" and/or \"PEAR.php\" not found"; }
                    elseif(count($_GET["files"]) < 1)
                          {
                            echo "Select at least one file.<br><br>";
                          }
                        else
                          {
                            ?>
                              <form method="post">
                              <input type="hidden" name="act" value="pack_go">
                              <?php
                              echo count($_GET["files"])." file".(count($_GET["files"]) > 1 ? "s" : "").":<br>";

                              for($i = 0; $i < count($_GET["files"]); $i++)
                                {
                                  $file = $list[($_GET["files"][$i])];
                                  ?>
                                  <input type="hidden" name="files[]" value="<?php echo $_GET["files"][$i]; ?>">
                                  <b><?php echo basename($file["name"]); ?></b><?php echo $i == count($_GET["files"]) - 1 ? "." : ",&nbsp;";
                                }
                              ?><br><br>
                               <table align="center">
                                 <tr>
                                   <td>
                                     Archive Name:&nbsp;<input type="text" name="arc_name" size="30">
                                   </td>
                                   <td>
                                     <input type="submit" value="Pack">
                                   </td>
                                 </tr>
                                 <tr>
                                   <td>
                                     Save To:&nbsp;<input type="text" name="path" size="30" value="<?php echo ($_COOKIE["path"] ? $_COOKIE["path"] : (strstr(realpath("./"), ":") ? addslashes(dirname(__FILE__)) : dirname(__FILE__))); ?>">
                                   </td>
                                 </tr>
                               </table>
                               <table align="center">
                                <tr>
                                  <td>
                                    For use compress gz or bz2 write extension as Tar.gz or Tar.bz2;<br>
                                    Else this archive will be uncompress Tar<br>
                                  </td>
                                </tr>
                               </table>
                              </form>
                            <?php
                          }
                      break;

                      case "pack_go":
                          if (!file_exists("Tar.php") || !file_exists("PEAR.php"))
                           { echo "Components \"Tar.php\" and \"PEAR.php\" not found"; break; }

                          $smthExists=true;
                          if(count($_GET["files"]) < 1)
                           { echo "Select at least one file.<br><br>"; break; }

                          $arc_name=$_GET["arc_name"];
                          if (!$arc_name)
                           { echo "Please enter an archive name!<br><br>"; break; };

                          if (file_exists($arc_name))
                           { echo "File <b>".$arc_name."</b> already exists!<br><br>"; break; }

                          for($i = 0; $i < count($_GET["files"]); $i++)
                           {
                            $file = $list[$_GET["files"][$i]];
                            if(file_exists($file["name"]))
                             {
                              $v_list[] = $file["name"];
                             } else
                             {
                               echo "File <b>".$file["name"]."</b> not found!<br><br>";
                             }
                           }
                          if (!$v_list)
                           { echo "An error occured!<br><br>"; break; }
                          $arc_name = $path.'/'.$arc_name;
                          //$arc_name = dirname($arc_name).PATH_SPLITTER.$arc_name;


                          require_once("Tar.php");
                          $tar = & new Archive_Tar($arc_name);
                          @$tar->create($v_list,$arc_method);
                          if (!file_exists($arc_name))
                           { echo "Error! Archive not created.<br><br>"; break; }

                          if (count($v_list  =  $tar->listContent()) > 0)
                           {
                             echo "File"; echo count($v_list)>1 ? "s" : ""; echo "<br>";
                              for ($i=0; $i<sizeof($v_list); $i++)
                               {
                                 /* ��� ���� � ��������� ����� ��������������� ���. �� �������� ����.
                                 if ($_GET["val_del_ok"])
                                  {
                                   if(@unlink($v_list["name"]))
                                   $v_ads=" and deleted";
                                  }
                                 else  $v_ads=", but not deleted !</b>";*/
                                 echo "File ".$v_list[$i]["filename"]." was packed <br>";
                               }
                              echo "Packed in archive <b>$arc_name</b><br>";


                              $stmp=strtolower($arc_name);
                              if (strrchr($stmp,"tar.gz"  )+5==strlen($stmp))
                                 {  $arc_method="Tar.gz"; }
                          elseif (strrchr($stmp,"tar.bz2" )+6==strlen($stmp))
                                 {  $arc_method="Tar.bz2";}
                          else   {  $arc_method="Tar";    };
                              unset($stmp);

                              $time = explode(" ", microtime());
                              $time = str_replace("0.", $time[1], $time[0]);
                              $list[$time] = array("name"    => $arc_name,
                                                   "size"    => bytesToKbOrMbOrGb(filesize($arc_name)),
                                                   "date"    => $time,
                                                   "link"    => "",
                                                   "comment" => "archive ".$arc_method);
                            } else { echo "Error! Archive is Empty.<br><br>"; }
                          if(!updateListInFile($list))
                            {
                             echo "Couldn't Update!<br><br>";
                            }
                          break;
                    }
                  _create_list();
                  if($list)
                    {
                  ?>
                   <script>
                    function setCheckboxes(act)
                    {
                      elts =  document.forms["flist"].elements["files[]"];
                      var elts_cnt  = (typeof(elts.length) != 'undefined') ? elts.length : 0;
                      if (elts_cnt)
                        {
                          for (var i = 0; i < elts_cnt; i++)
                            {
                              elts[i].checked = (act == 1 || act == 0) ? act : elts[i].checked ? 0 : 1;
                            }
                        }
                    }
                    <?php if ($show_all === true) { ?>
                    function showAll() {
                     <?php
                       $Path = parse_url($PHP_SELF);
                       $Path = substr($Path["path"], 0, strlen($Path["path"]) - strlen(strrchr($Path["path"], "?")));
                     ?>
                      if(getCookie("showAll") == 1)
                        {
                          deleteCookie("showAll");
                          location.href = "<?php echo $Path."?act=files"; ?>";
                        }
                      else
                        {
                          document.cookie = "showAll = 1;";
                          location.href = "<?php echo $Path."?act=files"; ?>";
                        }
                    }
                    <?php unset($Path); ?>
                    <?php } ?>
                  </script>
                  <form name="flist" method="post">
                  <a href="javascript:setCheckboxes(1);" style="color: #0000FF;">Check All</a> |
                  <a href="javascript:setCheckboxes(0);" style="color: #0000FF;">Un-Check All</a> |
                  <a href="javascript:setCheckboxes(2);" style="color: #0000FF;">Invert Selection</a>
<?php if ($show_all === true) { ?>|
                  <a href="javascript:showAll();" style="color: #0000FF;">Show
                  <script language="JavaScript">
                    if(getCookie("showAll") == 1)
                      {
                        document.write("Downloaded");
                      }
                    else
                      {
                        document.write("Everything");
                      }
                  </script></a><?php } ?><br><br>
                  <table cellpadding="3" cellspacing="1" width="100%">
                    <tbody>
                      <tr bgcolor="#E1E1E1" valign="bottom" align="center">
                        <td>
                          <select name="act" onChange="javascript:void(document.flist.submit());">
                            <option selected>Action</option>
                            <option value="mail">E-Mail</option>
                            <option value="boxes">Mass Submits</option>
                            <option value="split">Split Files</option>
                            <option value="merge">Merge Files</option>
                            <option value="ftp">FTP File</option>
                            <?php if (file_exists("PEAR.php") || file_exists("Tar.php")) print "<option value=\"pack\">Pack Files</option>".$nn; ?>
                            <?php if (file_exists("pclzip.php")) print "<option value=\"zip\">ZIP Files</option>".$nn; ?>
                            <option value="rename">Rename</option>
                            <option value="delete">Delete</option>
                          </select>
                        </td>
                        <td>Name</td>
                        <td>Size</td>
                        <td>Download Link</td>
                        <td>Comments</td>
                        <td>Date</td>
                      </tr>
                  <?php
                    }
                  else
                    {
                      echo "<center>No Files Found</center>";
                      if ($show_all === true) { ?>
                  <script>
                    function showAll() {
                     <?php
                       $Path = parse_url($PHP_SELF);
                       $Path = substr($Path["path"], 0, strlen($Path["path"]) - strlen(strrchr($Path["path"], "?")));
                     ?>
                      if(getCookie("showAll") == 1)
                        {
                          deleteCookie("showAll");
                          location.href = "<?php echo $Path."?act=files"; ?>";
                        }
                      else
                        {
                          document.cookie = "showAll = 1;";
                          location.href = "<?php echo $Path."?act=files"; ?>";
                        }
                    }
                  <?php unset($Path); ?>
                  </script>
                  <form name="flist" method="post">
                  <a href="javascript:showAll();" style="color: #0000FF;">Show
                  <script language="JavaScript">
                    if(getCookie("showAll") == 1)
                      {
                        document.write("Downloaded");
                      }
                    else
                      {
                        document.write("Everything");
                      }
                  </script></a><br><br><?php };
                    }
                  if($list)
                    {
                      $total_files=0;
                      foreach($list as $key => $file)
                        {
                          if(file_exists($file["name"]))
                            {
                              $total_files++;
                              $total_size+=filesize($file["name"]);
                              $inCurrDir = strstr(dirname($file["name"]), realpath("./")) ? TRUE : FALSE;
                              if($inCurrDir)
                                {
                                  $Path = parse_url($PHP_SELF);
                                  $Path = substr($Path["path"], 0, strlen($Path["path"]) - strlen(strrchr($Path["path"], "/")));
                                }
                              ?>
                              <tr onMouseOver="this.bgColor='#C8D0E6';" onMouseOut="this.bgColor='#F2F2F2';" align="center" bgcolor="#f2f2f2" title="<?php echo $file["name"]; ?>">
                                <td><input type=checkbox name="files[]" value="<?php echo $file["date"]; ?>"></td>
                                <td><?php echo $inCurrDir ? "<a href=\"".$Path.substr(dirname($file["name"]), strlen(realpath("./")) + 1)."/".basename($file["name"]) : ""; echo $inCurrDir ? "\">".basename($file["name"])."</a>" : basename($file["name"]); ?></td>
                                <td><?php echo $file["size"]; ?></td>
                                <td><?php echo $file["link"] ? "<a href=\"".$file["link"]."\" style=\"color: #0000FF;\">".$file["link"]."</a>" : "" ; ?></td>
                                <td><?php echo $file["comment"] ? str_replace("\\r\\n", "<br>", $file["comment"]) : ""; ?></td>
                                <td><?php echo date("d.m.Y H:i:s", $file["date"]) ?></td>
                              </tr>
                              <?php
                            }
                        }
                      if (($total_files>1) & ($total_size>0)) echo "<tr bgcolor=\"#E1E1E1\" align=\"center\">\n<td></td>\n<td>Total:</td>\n<td>".
                       bytesToKbOrMbOrGb($total_size)."</td>\n"."<td></td>\n<td></td>\n<td></td>\n</tr>";
                      unset($total_files,$total_size);
                    }
                  if($list)
                    {
                  ?>
                    </tbody>
            </table>
                    <form>
                  <?php
                    }
                  ?>
                </td>
              </tr>
      </table></td>
    <td valign="top">&nbsp;</td>
  </tr>
</table>
    </td>
  </tr>
</table>
<br>

<table width="60%" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      <div align="center"></div>
      <script>
      var show = 0;
      function showAdd(){
        document.getElementById('add').style.display = show ? 'none' : '';
        show = show ? 0 : 1;
      }

      var show2 = 0;
      function showAdd2(){
        document.getElementById('add2').style.display = show2 ? 'none' : '';
        show2 = show2 ? 0 : 1;
      }
      </script>
      <div align="center">
      </div>

      <div align="center"><hr>
<?php print VERSION; ?><br>
<hr></div>
    </td>
  </tr>
</table>
</body>
</html>