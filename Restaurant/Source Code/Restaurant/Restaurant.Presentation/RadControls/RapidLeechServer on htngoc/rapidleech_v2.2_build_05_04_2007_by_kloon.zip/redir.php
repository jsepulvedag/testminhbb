<?php
error_reporting(7);

foreach($_POST as $key => $value)
  {
    $_GET[$key] = $value;
  }

$capthatag = $_GET["capthatag"];
$rapid = $_GET["link"]."?$capthatag=". $_GET[$capthatag];

if ($_GET["useproxy"] == "on")
	{
		$useproxy = "&useproxy=on&proxy=".$_GET["proxy"].($_GET["pauth"] ? "&pauth=".$_GET["pauth"] : "");
	}
	
if ($_GET["domail"] == "on")
	{
	$domail = "&domail=on";
	}

$new_url = $_GET["redirto"]."?saveto=".$_GET["saveto"]."$useproxy&path=".$_GET["path"]."&comment=".$_GET["comment"].$domail."&email=".$_GET["email"]."&split=".$_GET["split"]."&method=".$_GET["method"]."&partSize=".$_GET["partSize"]."&link=".urlencode($rapid);

Header("Location: $new_url");
exit;
?>