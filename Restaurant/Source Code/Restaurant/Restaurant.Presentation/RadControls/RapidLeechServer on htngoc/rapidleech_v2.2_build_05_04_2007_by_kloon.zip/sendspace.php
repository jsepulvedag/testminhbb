<?php
function sendspace_enc($par1,$par2,$text)
{
$myarr=array();

for ($i=0;$i<$par1;$i++)
	{
		$myarr[$i]=$i;
	}
	
for ($j=0,$k=$j,$l=$myarr;$j<$par1;$j++)
	{
		$k=(ord($par2[$j%strlen($par2)])+$l[$j]+$k)%$par1;
		$m=$l[$j];
		$l[$j]=$l[$k];
		$l[$k]=$m;
		$l[$k]=$l[$k]^5;
	}

for ($res='',$k=0,$n=0;$n<strlen($text);$n++)
	{
		$o=$n%$par1;
		$k=($l[$o]+$k)%$par1;
		$p=$l[$o];
		$l[$o]=$l[$k];
		$l[$k]=$p;
		$res.=chr(ord($text[$n])^$l[($l[$o]+$l[$k])%$par1]);
	}

return $res;
}

function sendspace_base64ToText($t)
{
	$b64s='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"';
    $r='';
    $m=0;
    $a=0;
    $l=strlen($t);
    
    for($n=0; $n<$l; $n++)
    {
        $c=strpos($b64s,$t[$n]);
        if($c >= 0)
        {
            if($m)
            	{
            	$d=($c << (8-$m))& 255 | $a;
                $r.=chr($d);
                }
            $a = $c >> $m;
            $m+=2;
            if($m==8) {$m=0;}
        }
    }
    
    return $r;
}

?>